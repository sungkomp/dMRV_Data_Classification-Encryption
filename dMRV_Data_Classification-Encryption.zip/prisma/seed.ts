import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Clear existing data
  await prisma.protectionAction.deleteMany();
  await prisma.auditRecord.deleteMany();
  await prisma.extractedFeature.deleteMany();
  await prisma.riskAssessment.deleteMany();
  await prisma.asset.deleteMany();
  await prisma.protectionPolicy.deleteMany();
  await prisma.classificationRule.deleteMany();
  await prisma.riskReason.deleteMany();
  await prisma.simulationData.deleteMany();
  await prisma.classificationLevel.deleteMany();

  // Create Classification Levels
  const classificationLevels = await Promise.all([
    prisma.classificationLevel.create({
      data: {
        code: 'C1',
        name: 'Public',
        nameTh: 'สาธารณะ',
        description: 'Data that can be disclosed to the public without significant risk',
        descriptionTh: 'ข้อมูลที่เปิดเผยต่อสาธารณะได้โดยไม่มีความเสี่ยงอย่างมีนัยสำคัญ',
        riskLevel: 'Low',
        color: '#22C55E',
      },
    }),
    prisma.classificationLevel.create({
      data: {
        code: 'C2',
        name: 'Internal',
        nameTh: 'ภายใน',
        description: 'Data for internal organizational use that should not be publicly disclosed',
        descriptionTh: 'ข้อมูลสำหรับใช้ภายในองค์กรที่ไม่ควรเปิดเผยต่อสาธารณะ',
        riskLevel: 'Low-Medium',
        color: '#3B82F6',
      },
    }),
    prisma.classificationLevel.create({
      data: {
        code: 'C3',
        name: 'Confidential',
        nameTh: 'ลับ',
        description: 'Sensitive data that could impact business operations if disclosed',
        descriptionTh: 'ข้อมูลที่หากรั่วไหลจะกระทบธุรกิจการดำเนินงาน',
        riskLevel: 'Medium-High',
        color: '#F59E0B',
      },
    }),
    prisma.classificationLevel.create({
      data: {
        code: 'C4',
        name: 'Restricted',
        nameTh: 'จำกัด',
        description: 'Highly sensitive data requiring strict access controls',
        descriptionTh: 'ข้อมูลที่มีความอ่อนไหวสูงต้องการการควบคุมการเข้าถึงเข้มงวด',
        riskLevel: 'High',
        color: '#EF4444',
      },
    }),
    prisma.classificationLevel.create({
      data: {
        code: 'C5',
        name: 'Evidence-Critical',
        nameTh: 'หลักฐานสำคัญ',
        description: 'Critical evidence data for verification, audit, and certification',
        descriptionTh: 'ข้อมูลหลักฐานสำคัญสำหรับการตรวจสอบ รับรอง และพิสูจน์',
        riskLevel: 'Critical',
        color: '#7C3AED',
      },
    }),
  ]);

  // Create Protection Policies
  const c1Level = classificationLevels.find(l => l.code === 'C1')!;
  const c2Level = classificationLevels.find(l => l.code === 'C2')!;
  const c3Level = classificationLevels.find(l => l.code === 'C3')!;
  const c4Level = classificationLevels.find(l => l.code === 'C4')!;
  const c5Level = classificationLevels.find(l => l.code === 'C5')!;

  await Promise.all([
    prisma.protectionPolicy.create({
      data: {
        name: 'Public Data Policy',
        classificationId: c1Level.id,
        encryptionAtRest: 'standard',
        encryptionInTransit: 'tls',
        accessControl: 'open',
        auditLogging: false,
        externalSharing: true,
        retentionYears: 1,
      },
    }),
    prisma.protectionPolicy.create({
      data: {
        name: 'Internal Data Policy',
        classificationId: c2Level.id,
        encryptionAtRest: 'standard',
        encryptionInTransit: 'tls',
        accessControl: 'auth',
        auditLogging: true,
        externalSharing: false,
        retentionYears: 3,
      },
    }),
    prisma.protectionPolicy.create({
      data: {
        name: 'Confidential Data Policy',
        classificationId: c3Level.id,
        encryptionAtRest: 'strong',
        encryptionInTransit: 'tls',
        fieldEncryption: true,
        accessControl: 'rbac',
        auditLogging: true,
        detailedLogging: true,
        externalSharing: false,
        retentionYears: 5,
      },
    }),
    prisma.protectionPolicy.create({
      data: {
        name: 'Restricted Data Policy',
        classificationId: c4Level.id,
        encryptionAtRest: 'strong',
        encryptionInTransit: 'mtls',
        fieldEncryption: true,
        tokenization: true,
        accessControl: 'strict-rbac',
        mfaRequired: true,
        auditLogging: true,
        detailedLogging: true,
        exportApproval: true,
        externalSharing: false,
        retentionYears: 7,
      },
    }),
    prisma.protectionPolicy.create({
      data: {
        name: 'Evidence-Critical Data Policy',
        classificationId: c5Level.id,
        encryptionAtRest: 'envelope',
        encryptionInTransit: 'mtls',
        fieldEncryption: true,
        accessControl: 'dual-control',
        mfaRequired: true,
        immutableStorage: true,
        wormStorage: true,
        evidenceVault: true,
        auditLogging: true,
        detailedLogging: true,
        exportApproval: true,
        externalSharing: false,
        retentionYears: 10,
        backupFrequency: 'daily',
        backupType: 'pitr',
      },
    }),
  ]);

  // Create Classification Rules
  await Promise.all([
    prisma.classificationRule.create({
      data: {
        ruleId: 'R01',
        name: 'PII Detection Rule',
        nameTh: 'กฎตรวจจับข้อมูลส่วนบุคคล',
        description: 'If PII (personal ID, passport, owner data) is detected',
        condition: JSON.stringify({ hasPII: true }),
        minClass: 'C4',
        priority: 100,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R02',
        name: 'Geospatial Sensitivity Rule',
        nameTh: 'กฎความไวต่อพื้นที่',
        description: 'If exact GPS/parcel polygon with owner linkage',
        condition: JSON.stringify({ hasExactLocation: true, hasOwnerLink: true }),
        minClass: 'C4',
        priority: 90,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R03',
        name: 'Carbon Calculation Rule',
        nameTh: 'กฎข้อมูลคำนวณคาร์บอน',
        description: 'Raw telemetry used in carbon calculation',
        condition: JSON.stringify({ isCarbonCritical: true, isRawTelemetry: true }),
        minClass: 'C4',
        priority: 85,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R04',
        name: 'Verification Package Rule',
        nameTh: 'กฎแพ็คเกจตรวจสอบ',
        description: 'Approved calculation result for registry submission',
        condition: JSON.stringify({ isApproved: true, isForRegistry: true }),
        minClass: 'C5',
        priority: 95,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R05',
        name: 'Signed Evidence Rule',
        nameTh: 'กฎหลักฐานที่ลงนาม',
        description: 'Signed verification report or audit package',
        condition: JSON.stringify({ isSigned: true, isEvidence: true }),
        minClass: 'C5',
        priority: 95,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R06',
        name: 'Calibration Certificate Rule',
        nameTh: 'กฎใบรับรองสอบเทียบ',
        description: 'Calibration certificate or chain of custody',
        condition: JSON.stringify({ isCalibrationCert: true }),
        minClass: 'C5',
        priority: 90,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R07',
        name: 'High Resolution Imagery Rule',
        nameTh: 'กฎภาพความละเอียดสูง',
        description: 'Drone imagery of private property',
        condition: JSON.stringify({ isHighResImagery: true, isPrivateProperty: true }),
        minClass: 'C3',
        priority: 70,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R08',
        name: 'Aggregate Analytics Rule',
        nameTh: 'กฎข้อมูลรวม',
        description: 'LiDAR/imagery derived analytics aggregate',
        condition: JSON.stringify({ isAggregate: true, noPersonalData: true }),
        minClass: 'C2',
        priority: 50,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R09',
        name: 'Security Configuration Rule',
        nameTh: 'กฎการตั้งค่าความปลอดภัย',
        description: 'Security topology, certificate metadata, credentials',
        condition: JSON.stringify({ isSecurityConfig: true }),
        minClass: 'C4',
        priority: 95,
      },
    }),
    prisma.classificationRule.create({
      data: {
        ruleId: 'R10',
        name: 'Public Release Rule',
        nameTh: 'กฎการเผยแพร่สาธารณะ',
        description: 'Public report approved for release',
        condition: JSON.stringify({ isPublicReport: true, isReleaseApproved: true }),
        minClass: 'C1',
        priority: 80,
      },
    }),
  ]);

  // Create Risk Reasons
  await Promise.all([
    prisma.riskReason.create({
      data: {
        code: 'RR01',
        name: 'Personal Privacy Exposure',
        nameTh: 'การเปิดเผยข้อมูลส่วนบุคคล',
        description: 'Data can identify individuals or link to parcel owners',
        descriptionTh: 'ข้อมูลสามารถระบุตัวบุคคลหรือเชื่อมโยงเจ้าของแปลงได้',
        category: 'privacy',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR02',
        name: 'Property/Location Sensitivity',
        nameTh: 'ความไวต่อทรัพย์สิน/ที่ตั้ง',
        description: 'Data reveals property details, boundaries, or precise locations',
        descriptionTh: 'ข้อมูลระบุทรัพย์สิน ขอบเขตพื้นที่ หรือพิกัดแบบละเอียด',
        category: 'security',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR03',
        name: 'Carbon Calculation Integrity',
        nameTh: 'ความถูกต้องของการคำนวณคาร์บอน',
        description: 'Data used in MRV or credit calculation directly',
        descriptionTh: 'ข้อมูลถูกใช้ในการคำนวณผล MRV หรือเครดิตโดยตรง',
        category: 'integrity',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR04',
        name: 'Verification Evidence Value',
        nameTh: 'คุณค่าหลักฐานการตรวจสอบ',
        description: 'Data serves as key evidence for verification and certification',
        descriptionTh: 'ข้อมูลเป็นหลักฐานสำคัญสำหรับการตรวจสอบและการรับรอง',
        category: 'compliance',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR05',
        name: 'Legal/Contractual Obligation',
        nameTh: 'ข้อผูกพันทางกฎหมาย/สัญญา',
        description: 'Data subject to laws, regulations, or contractual restrictions',
        descriptionTh: 'ข้อมูลอยู่ภายใต้กฎหมาย ข้อกำหนด หรือสัญญา',
        category: 'compliance',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR06',
        name: 'Strategic/IP Sensitivity',
        nameTh: 'ความไวทางกลยุทธ์/ทรัพย์สินทางปัญญา',
        description: 'Data has business value or is intellectual property',
        descriptionTh: 'ข้อมูลมีมูลค่าทางธุรกิจหรือเป็นทรัพย์สินทางปัญญา',
        category: 'business',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR07',
        name: 'System Security Exposure',
        nameTh: 'การเปิดเผยความปลอดภัยของระบบ',
        description: 'Data could be used to attack systems or escalate privileges',
        descriptionTh: 'ข้อมูลสามารถนำไปใช้โจมตีระบบหรือยกระดับสิทธิ์',
        category: 'security',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR08',
        name: 'Non-repudiation Requirement',
        nameTh: 'ข้อกำหนดการปฏิเสธไม่ได้',
        description: 'Must be able to prove origin, approval, and chain of custody',
        descriptionTh: 'ต้องพิสูจน์ได้ว่าใครเป็นผู้สร้าง ส่ง หรืออนุมัติข้อมูล',
        category: 'compliance',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR09',
        name: 'High Recovery Cost',
        nameTh: 'ต้นทุนการกู้คืนสูง',
        description: 'Loss would incur high cost to recollect or restore',
        descriptionTh: 'หากสูญหายจะมีต้นทุนสูงในการเก็บใหม่หรือกู้คืน',
        category: 'business',
      },
    }),
    prisma.riskReason.create({
      data: {
        code: 'RR10',
        name: 'Operational Disruption',
        nameTh: 'การหยุดชะงักของการปฏิบัติงาน',
        description: 'Unavailability would significantly impact operations',
        descriptionTh: 'หากเข้าไม่ถึงจะกระทบการปฏิบัติงานอย่างมีนัยสำคัญ',
        category: 'business',
      },
    }),
  ]);

  // Create Simulation Data with realistic examples
  await Promise.all([
    // Sensor/IoT Data
    prisma.simulationData.create({
      data: {
        name: 'Methane Sensor Telemetry',
        dataType: 'sensor',
        sampleData: JSON.stringify({
          device_id: 'RICE_METHANE_001',
          timestamp: '2026-01-15T10:00:00Z',
          parameter: 'CH4_flux',
          value: 0.032,
          unit: 'mg/m2/hr',
          qc_flag: 'OK',
          location: { lat: 13.7563, lng: 100.5018 },
          project_id: 'CARBON_RICE_2026',
        }),
        expectedClass: 'C4',
        riskFactors: JSON.stringify({
          piiScore: 0,
          geospatialScore: 2,
          carbonCriticality: 5,
          evidenceValue: 4,
          legalScore: 2,
          businessScore: 3,
          integrityScore: 5,
          availabilityScore: 4,
          traceabilityScore: 5,
          securityScore: 2,
        }),
        description: 'Real-time methane flux measurement from rice field sensor',
      },
    }),
    prisma.simulationData.create({
      data: {
        name: 'Soil Moisture Sensor',
        dataType: 'sensor',
        sampleData: JSON.stringify({
          device_id: 'SOIL_MOIST_001',
          timestamp: '2026-01-15T10:05:00Z',
          parameter: 'soil_moisture',
          value: 45.2,
          unit: '%',
          depth_cm: 10,
          qc_flag: 'OK',
        }),
        expectedClass: 'C2',
        riskFactors: JSON.stringify({
          piiScore: 0,
          geospatialScore: 1,
          carbonCriticality: 2,
          evidenceValue: 1,
          legalScore: 0,
          businessScore: 2,
          integrityScore: 3,
          availabilityScore: 2,
          traceabilityScore: 2,
          securityScore: 1,
        }),
        description: 'Soil moisture measurement for agricultural monitoring',
      },
    }),
    // LiDAR Data
    prisma.simulationData.create({
      data: {
        name: 'Forest Biomass LiDAR',
        dataType: 'lidar',
        sampleData: JSON.stringify({
          mission_id: 'LIDAR_2026_FOREST_A',
          sensor: 'RIEGL VUX',
          point_density: '15 points/m2',
          coverage_ha: 500,
          acquisition_date: '2026-01-10',
          project_id: 'FOREST_CARBON_2026',
          file_format: 'LAS',
          file_size_gb: 45,
        }),
        expectedClass: 'C5',
        riskFactors: JSON.stringify({
          piiScore: 0,
          geospatialScore: 3,
          carbonCriticality: 5,
          evidenceValue: 5,
          legalScore: 3,
          businessScore: 4,
          integrityScore: 5,
          availabilityScore: 3,
          traceabilityScore: 5,
          securityScore: 2,
        }),
        description: 'High-density LiDAR point cloud for forest biomass estimation',
      },
    }),
    // Satellite Data
    prisma.simulationData.create({
      data: {
        name: 'Sentinel-2 Imagery',
        dataType: 'satellite',
        sampleData: JSON.stringify({
          scene_id: 'S2A_20260115_T47PQS',
          satellite: 'Sentinel-2A',
          acquisition_date: '2026-01-15',
          cloud_cover: 12.5,
          resolution_m: 10,
          bands: ['B02', 'B03', 'B04', 'B08'],
          bbox: [100.0, 13.5, 101.0, 14.5],
          file_size_gb: 0.8,
        }),
        expectedClass: 'C2',
        riskFactors: JSON.stringify({
          piiScore: 0,
          geospatialScore: 1,
          carbonCriticality: 2,
          evidenceValue: 2,
          legalScore: 0,
          businessScore: 2,
          integrityScore: 2,
          availabilityScore: 3,
          traceabilityScore: 3,
          securityScore: 1,
        }),
        description: 'Sentinel-2 multispectral imagery for NDVI analysis',
      },
    }),
    // Drone Data
    prisma.simulationData.create({
      data: {
        name: 'Drone Orthomosaic',
        dataType: 'drone',
        sampleData: JSON.stringify({
          flight_id: 'DRONE_RICE_2026_001',
          drone_model: 'DJI Phantom 4 RTK',
          camera: 'multispectral',
          gsd_cm: 5,
          coverage_ha: 50,
          flight_date: '2026-01-15',
          altitude_m: 120,
          project_id: 'CARBON_RICE_2026',
          parcel_ids: ['PARCEL_001', 'PARCEL_002'],
        }),
        expectedClass: 'C3',
        riskFactors: JSON.stringify({
          piiScore: 2,
          geospatialScore: 4,
          carbonCriticality: 3,
          evidenceValue: 3,
          legalScore: 2,
          businessScore: 3,
          integrityScore: 4,
          availabilityScore: 2,
          traceabilityScore: 4,
          securityScore: 2,
        }),
        description: 'High-resolution drone orthomosaic of rice fields',
      },
    }),
    // Evidence Document
    prisma.simulationData.create({
      data: {
        name: 'Verification Report (Signed)',
        dataType: 'evidence',
        sampleData: JSON.stringify({
          document_id: 'VER_RPT_2026_001',
          type: 'verification_report',
          verifier: 'TÜV Rheinland',
          verification_date: '2026-01-20',
          project_id: 'FOREST_CARBON_2026',
          status: 'approved',
          signed: true,
          signature_algorithm: 'RSA-2048',
          signature_date: '2026-01-21',
          pages: 45,
        }),
        expectedClass: 'C5',
        riskFactors: JSON.stringify({
          piiScore: 2,
          geospatialScore: 2,
          carbonCriticality: 5,
          evidenceValue: 5,
          legalScore: 5,
          businessScore: 5,
          integrityScore: 5,
          availabilityScore: 4,
          traceabilityScore: 5,
          securityScore: 3,
        }),
        description: 'Signed verification report from accredited verifier',
      },
    }),
    // Calibration Certificate
    prisma.simulationData.create({
      data: {
        name: 'Sensor Calibration Certificate',
        dataType: 'evidence',
        sampleData: JSON.stringify({
          cert_id: 'CAL_2026_001',
          device_id: 'RICE_METHANE_001',
          calibration_date: '2025-12-01',
          valid_until: '2026-12-01',
          calibration_lab: 'NIMT Accredited Lab',
          standard: 'ISO 17025',
          signed: true,
          parameters: ['CH4_accuracy', 'CH4_precision', 'zero_drift'],
        }),
        expectedClass: 'C5',
        riskFactors: JSON.stringify({
          piiScore: 0,
          geospatialScore: 0,
          carbonCriticality: 4,
          evidenceValue: 5,
          legalScore: 4,
          businessScore: 3,
          integrityScore: 5,
          availabilityScore: 3,
          traceabilityScore: 5,
          securityScore: 1,
        }),
        description: 'Calibration certificate for methane sensor',
      },
    }),
    // Public Report
    prisma.simulationData.create({
      data: {
        name: 'Annual Carbon Report (Public)',
        dataType: 'document',
        sampleData: JSON.stringify({
          report_id: 'CARBON_RPT_2025',
          title: 'Annual Carbon Sequestration Report 2025',
          publish_date: '2026-02-01',
          status: 'published',
          public_access: true,
          aggregate_data: true,
          pages: 30,
        }),
        expectedClass: 'C1',
        riskFactors: JSON.stringify({
          piiScore: 0,
          geospatialScore: 0,
          carbonCriticality: 1,
          evidenceValue: 1,
          legalScore: 0,
          businessScore: 1,
          integrityScore: 2,
          availabilityScore: 1,
          traceabilityScore: 1,
          securityScore: 0,
        }),
        description: 'Public annual carbon sequestration report',
      },
    }),
    // Parcel Owner Data
    prisma.simulationData.create({
      data: {
        name: 'Parcel Owner Registry',
        dataType: 'database',
        sampleData: JSON.stringify({
          table_name: 'parcel_owner_master',
          columns: ['parcel_id', 'owner_name', 'owner_id_card', 'phone', 'address', 'geometry'],
          row_count: 1250,
          contains_pii: true,
          contains_geometry: true,
        }),
        expectedClass: 'C4',
        riskFactors: JSON.stringify({
          piiScore: 5,
          geospatialScore: 5,
          carbonCriticality: 3,
          evidenceValue: 2,
          legalScore: 5,
          businessScore: 3,
          integrityScore: 4,
          availabilityScore: 3,
          traceabilityScore: 4,
          securityScore: 4,
        }),
        description: 'Master table linking parcels to owners with PII',
      },
    }),
    // Security Configuration
    prisma.simulationData.create({
      data: {
        name: 'API Security Credentials',
        dataType: 'document',
        sampleData: JSON.stringify({
          type: 'api_credentials',
          service: 'data_ingestion_api',
          created: '2026-01-01',
          expires: '2027-01-01',
          contains_secrets: true,
        }),
        expectedClass: 'C4',
        riskFactors: JSON.stringify({
          piiScore: 0,
          geospatialScore: 0,
          carbonCriticality: 0,
          evidenceValue: 0,
          legalScore: 3,
          businessScore: 4,
          integrityScore: 3,
          availabilityScore: 5,
          traceabilityScore: 3,
          securityScore: 5,
        }),
        description: 'API keys and security tokens for system integration',
      },
    }),
  ]);

  console.log('Seed data created successfully!');
  console.log('Classification Levels:', classificationLevels.length);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
