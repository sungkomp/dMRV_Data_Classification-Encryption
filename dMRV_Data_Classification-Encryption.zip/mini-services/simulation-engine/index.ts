import { Server as HttpServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const PORT = 3010;

// Data source configurations
const dataSources = [
  {
    type: 'sensor',
    name: 'Methane Sensor',
    baseData: {
      device_id: 'CH4_SENSOR',
      parameter: 'CH4_flux',
      unit: 'mg/m2/hr',
    },
    riskRange: { min: 15, max: 40 },
    interval: 3000,
  },
  {
    type: 'sensor',
    name: 'Soil Moisture Sensor',
    baseData: {
      device_id: 'SOIL_MOIST',
      parameter: 'soil_moisture',
      unit: '%',
    },
    riskRange: { min: 8, max: 20 },
    interval: 5000,
  },
  {
    type: 'lidar',
    name: 'Forest LiDAR Scanner',
    baseData: {
      mission_id: 'LIDAR_FOREST',
      sensor: 'RIEGL VUX',
      point_density: '15 points/m2',
    },
    riskRange: { min: 30, max: 48 },
    interval: 15000,
  },
  {
    type: 'satellite',
    name: 'Sentinel-2 Imagery',
    baseData: {
      satellite: 'Sentinel-2A',
      resolution_m: 10,
      bands: ['B02', 'B03', 'B04', 'B08'],
    },
    riskRange: { min: 8, max: 22 },
    interval: 10000,
  },
  {
    type: 'drone',
    name: 'Drone Survey',
    baseData: {
      drone_model: 'DJI Phantom 4 RTK',
      camera: 'multispectral',
      gsd_cm: 5,
    },
    riskRange: { min: 18, max: 35 },
    interval: 8000,
  },
  {
    type: 'evidence',
    name: 'Verification Document',
    baseData: {
      type: 'verification_report',
      verifier: 'TÜV Rheinland',
    },
    riskRange: { min: 35, max: 50 },
    interval: 20000,
  },
];

// Risk score generators
function generateRiskScores(totalTarget: number): Record<string, number> {
  const factors = [
    'piiScore',
    'geospatialScore', 
    'carbonCriticality',
    'evidenceValue',
    'legalScore',
    'businessScore',
    'integrityScore',
    'availabilityScore',
    'traceabilityScore',
    'securityScore',
  ];
  
  const scores: Record<string, number> = {};
  let remaining = totalTarget;
  
  factors.forEach((factor, index) => {
    if (index === factors.length - 1) {
      scores[factor] = Math.min(5, Math.max(0, remaining));
    } else {
      const max = Math.min(5, remaining);
      const min = Math.max(0, remaining - (factors.length - index - 1) * 5);
      scores[factor] = Math.floor(Math.random() * (max - min + 1)) + min;
      remaining -= scores[factor];
    }
  });
  
  return scores;
}

// Classification logic
function calculateClassification(totalScore: number): string {
  if (totalScore <= 8) return 'C1';
  if (totalScore <= 15) return 'C2';
  if (totalScore <= 24) return 'C3';
  if (totalScore <= 35) return 'C4';
  return 'C5';
}

function applyOverrides(scores: Record<string, number>): { minClass: string | null; rules: string[] } {
  const matchedRules: string[] = [];
  let minClass: string | null = null;

  if (scores.piiScore >= 4) {
    matchedRules.push('R01');
    minClass = 'C4';
  }

  if (scores.piiScore >= 4 && scores.geospatialScore >= 4) {
    matchedRules.push('R02');
    minClass = 'C4';
  }

  if (scores.carbonCriticality >= 5) {
    matchedRules.push('R03');
    if (!minClass || minClass < 'C4') minClass = 'C4';
  }

  if (scores.evidenceValue >= 5 && scores.traceabilityScore >= 5) {
    matchedRules.push('R04');
    matchedRules.push('R05');
    minClass = 'C5';
  }

  if (scores.evidenceValue >= 5 && scores.integrityScore >= 5) {
    matchedRules.push('R06');
    minClass = 'C5';
  }

  if (scores.securityScore >= 4) {
    matchedRules.push('R09');
    if (!minClass || minClass < 'C4') minClass = 'C4';
  }

  return { minClass, rules: matchedRules };
}

// Generate unique ID
function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// Main simulation
async function runSimulation(io: SocketIOServer) {
  console.log('🚀 Simulation Engine Started on port', PORT);
  
  // Get classification levels from database
  const levels = await prisma.classificationLevel.findMany();
  const levelMap = new Map(levels.map(l => [l.code, l]));
  
  let classificationCount = 0;
  
  dataSources.forEach((source) => {
    setInterval(async () => {
      try {
        // Generate risk scores
        const targetScore = Math.floor(
          Math.random() * (source.riskRange.max - source.riskRange.min + 1) + source.riskRange.min
        );
        const riskScores = generateRiskScores(targetScore);
        const totalScore = Object.values(riskScores).reduce((a, b) => a + b, 0);
        
        // Calculate classification
        const baseClass = calculateClassification(totalScore);
        const overrides = applyOverrides(riskScores);
        
        let finalClass = baseClass;
        if (overrides.minClass) {
          const classOrder = ['C1', 'C2', 'C3', 'C4', 'C5'];
          const baseIndex = classOrder.indexOf(baseClass);
          const overrideIndex = classOrder.indexOf(overrides.minClass);
          if (overrideIndex > baseIndex) {
            finalClass = overrides.minClass;
          }
        }
        
        const confidence = Math.min(0.5 + overrides.rules.length * 0.1 + Math.random() * 0.3, 0.99);
        const level = levelMap.get(finalClass);
        
        // Generate asset name
        const timestamp = new Date().toISOString().split('T')[0];
        const assetName = `${source.name}_${timestamp}_${++classificationCount}`;
        
        // Create sample data
        const sampleData = {
          ...source.baseData,
          timestamp: new Date().toISOString(),
          value: source.type === 'sensor' ? (Math.random() * 100).toFixed(2) : undefined,
          project_id: `PROJECT_${Math.floor(Math.random() * 10) + 1}`,
        };
        
        // Create asset in database
        const asset = await prisma.asset.create({
          data: {
            name: assetName,
            sourceType: source.type,
            classificationId: level?.id,
            confidence,
            decisionSource: overrides.rules.length > 0 ? 'rules+risk' : 'risk',
            ...riskScores,
            totalRiskScore: totalScore,
            workflowState: 'raw',
          }
        });
        
        // Create audit record
        await prisma.auditRecord.create({
          data: {
            assetId: asset.id,
            eventType: 'classify',
            actor: 'Simulation Engine',
            actorType: 'system',
            description: `Auto-classified as ${finalClass} with ${(confidence * 100).toFixed(1)}% confidence`,
            newClassification: finalClass,
            decisionTrace: JSON.stringify({
              totalScore,
              baseClass,
              finalClass,
              matchedRules: overrides.rules,
              confidence,
            }),
          }
        });
        
        // Emit to clients
        const event = {
          id: generateId(),
          assetId: asset.id,
          assetName,
          sourceType: source.type,
          sourceName: source.name,
          classification: finalClass,
          classificationName: level?.name || 'Unknown',
          classificationColor: level?.color || '#888',
          confidence,
          totalScore,
          riskScores,
          matchedRules: overrides.rules,
          sampleData,
          timestamp: new Date().toISOString(),
        };
        
        io.emit('classification', event);
        io.emit('stats', {
          totalClassifications: classificationCount,
          lastClassification: event,
        });
        
        console.log(`📊 [${source.type}] ${assetName} → ${finalClass} (${(confidence * 100).toFixed(1)}%)`);
        
      } catch (error) {
        console.error('Simulation error:', error);
      }
    }, source.interval + Math.random() * 2000);
  });
}

// Start server
const httpServer = new HttpServer();
const io = new SocketIOServer(httpServer, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

io.on('connection', (socket) => {
  console.log('📡 Client connected:', socket.id);
  
  socket.emit('connected', { 
    message: 'Connected to dMRV Simulation Engine',
    sources: dataSources.map(s => ({ type: s.type, name: s.name })),
  });
  
  socket.on('disconnect', () => {
    console.log('📡 Client disconnected:', socket.id);
  });
});

httpServer.listen(PORT, () => {
  runSimulation(io);
});
