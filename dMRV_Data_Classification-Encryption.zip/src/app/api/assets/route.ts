import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const classificationId = searchParams.get('classificationId');
    const sourceType = searchParams.get('sourceType');
    
    const where: Record<string, unknown> = {};
    if (classificationId) where.classificationId = classificationId;
    if (sourceType) where.sourceType = sourceType;
    
    const assets = await db.asset.findMany({
      where,
      include: {
        classification: true,
        riskAssessment: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    
    return NextResponse.json(assets);
  } catch (error) {
    console.error('Error fetching assets:', error);
    return NextResponse.json({ error: 'Failed to fetch assets' }, { status: 500 });
  }
}
