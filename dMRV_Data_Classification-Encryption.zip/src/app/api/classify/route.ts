import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Risk score to classification mapping
function calculateClassification(totalScore: number): string {
  if (totalScore <= 8) return 'C1';
  if (totalScore <= 15) return 'C2';
  if (totalScore <= 24) return 'C3';
  if (totalScore <= 35) return 'C4';
  return 'C5';
}

// Override rules
function applyOverrides(scores: Record<string, number>, matchedRules: string[]): { minClass: string | null, reasons: string[] } {
  const overrides: { minClass: string, reasons: string[] } = { minClass: null, reasons: [] };
  
  // R01: PII + exact location → at least C4
  if (scores.piiScore >= 4 && scores.geospatialScore >= 4) {
    if (!overrides.minClass || overrides.minClass < 'C4') {
      overrides.minClass = 'C4';
      overrides.reasons.push('PII with exact geolocation detected');
    }
  }
  
  // R04/R05: Signed verification/approved calculation → at least C5
  if (matchedRules.includes('R04') || matchedRules.includes('R05')) {
    overrides.minClass = 'C5';
    overrides.reasons.push('Signed verification or approved evidence detected');
  }
  
  // R06: Calibration certificate → at least C5
  if (matchedRules.includes('R06')) {
    overrides.minClass = 'C5';
    overrides.reasons.push('Calibration certificate detected');
  }
  
  // R01: PII detected → at least C4
  if (scores.piiScore >= 4) {
    if (!overrides.minClass || overrides.minClass < 'C4') {
      overrides.minClass = 'C4';
      overrides.reasons.push('PII detected');
    }
  }
  
  // Security credentials → at least C4
  if (scores.securityScore >= 4) {
    if (!overrides.minClass || overrides.minClass < 'C4') {
      overrides.minClass = 'C4';
      overrides.reasons.push('Security-sensitive data detected');
    }
  }
  
  return overrides;
}

// Calculate confidence based on rule matches and score distribution
function calculateConfidence(
  baseScore: number, 
  matchedRules: string[], 
  overrides: { minClass: string | null }
): number {
  let confidence = 0.5;
  
  // Higher confidence with more matched rules
  confidence += Math.min(matchedRules.length * 0.1, 0.3);
  
  // Higher confidence if score clearly indicates a class
  const scoreRanges = [
    { max: 8, weight: 0.2 },
    { max: 15, weight: 0.15 },
    { max: 24, weight: 0.1 },
    { max: 35, weight: 0.15 },
    { max: 50, weight: 0.2 },
  ];
  
  for (const range of scoreRanges) {
    if (baseScore <= range.max) {
      confidence += range.weight;
      break;
    }
  }
  
  // Override rules increase confidence
  if (overrides.minClass) {
    confidence += 0.15;
  }
  
  return Math.min(confidence, 0.99);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      name, 
      sourceType, 
      riskScores, 
      matchedRules = [],
      metadata = {}
    } = body;
    
    // Get classification levels
    const levels = await db.classificationLevel.findMany();
    const levelMap = new Map(levels.map(l => [l.code, l]));
    
    // Calculate total risk score
    const totalScore = Object.values(riskScores).reduce((sum: number, score) => sum + (score as number), 0);
    
    // Get base classification from score
    const baseClass = calculateClassification(totalScore);
    
    // Apply override rules
    const overrides = applyOverrides(riskScores, matchedRules);
    
    // Determine final classification
    let finalClass = baseClass;
    if (overrides.minClass) {
      const classOrder = ['C1', 'C2', 'C3', 'C4', 'C5'];
      const baseIndex = classOrder.indexOf(baseClass);
      const overrideIndex = classOrder.indexOf(overrides.minClass);
      if (overrideIndex > baseIndex) {
        finalClass = overrides.minClass;
      }
    }
    
    // Calculate confidence
    const confidence = calculateConfidence(totalScore, matchedRules, overrides);
    
    // Get the classification level
    const classification = levelMap.get(finalClass);
    
    if (!classification) {
      return NextResponse.json({ error: 'Invalid classification' }, { status: 500 });
    }
    
    // Create asset record
    const asset = await db.asset.create({
      data: {
        name,
        sourceType,
        classificationId: classification.id,
        confidence,
        decisionSource: matchedRules.length > 0 ? 'rules+risk' : 'risk',
        piiScore: riskScores.piiScore || 0,
        geospatialScore: riskScores.geospatialScore || 0,
        carbonCriticality: riskScores.carbonCriticality || 0,
        evidenceValue: riskScores.evidenceValue || 0,
        legalScore: riskScores.legalScore || 0,
        businessScore: riskScores.businessScore || 0,
        integrityScore: riskScores.integrityScore || 0,
        availabilityScore: riskScores.availabilityScore || 0,
        traceabilityScore: riskScores.traceabilityScore || 0,
        securityScore: riskScores.securityScore || 0,
        totalRiskScore: totalScore,
        workflowState: metadata.workflowState || 'raw',
        projectId: metadata.projectId,
        parcelId: metadata.parcelId,
        owner: metadata.owner,
      }
    });
    
    // Create risk assessment record
    await db.riskAssessment.create({
      data: {
        assetId: asset.id,
        confidentiality: riskScores.piiScore || 0,
        integrity: riskScores.integrityScore || 0,
        availability: riskScores.availabilityScore || 0,
        auditability: riskScores.traceabilityScore || 0,
        legal: riskScores.legalScore || 0,
        privacy: riskScores.piiScore || 0,
        business: riskScores.businessScore || 0,
        securityExploit: riskScores.securityScore || 0,
        overallRisk: classification.riskLevel,
        riskReasons: JSON.stringify(overrides.reasons),
      }
    });
    
    // Create audit record
    await db.auditRecord.create({
      data: {
        assetId: asset.id,
        eventType: 'classify',
        actor: 'Auto Classification Engine',
        actorType: 'system',
        description: `Auto-classified as ${finalClass} with ${(confidence * 100).toFixed(1)}% confidence`,
        newClassification: finalClass,
        decisionTrace: JSON.stringify({
          baseScore,
          baseClass,
          matchedRules,
          overrides: overrides.reasons,
          finalClass,
          confidence,
        }),
      }
    });
    
    // Get protection policy for this classification
    const policy = await db.protectionPolicy.findFirst({
      where: { classificationId: classification.id }
    });
    
    // Generate protection actions
    const protectionActions = [];
    if (policy) {
      if (policy.encryptionAtRest && policy.encryptionAtRest !== 'none') {
        protectionActions.push({
          action: 'encrypt_at_rest',
          method: policy.encryptionAtRest,
          status: 'pending'
        });
      }
      if (policy.fieldEncryption) {
        protectionActions.push({
          action: 'field_encryption',
          status: 'pending'
        });
      }
      if (policy.tokenization) {
        protectionActions.push({
          action: 'tokenize_pii',
          status: 'pending'
        });
      }
      if (policy.immutableStorage) {
        protectionActions.push({
          action: 'move_to_immutable_vault',
          status: 'pending'
        });
      }
      if (policy.evidenceVault) {
        protectionActions.push({
          action: 'store_in_evidence_vault',
          status: 'pending'
        });
      }
      if (policy.detailedLogging) {
        protectionActions.push({
          action: 'enable_detailed_audit',
          status: 'pending'
        });
      }
    }
    
    return NextResponse.json({
      asset,
      classification,
      riskAssessment: {
        totalScore,
        scores: riskScores,
        overallRisk: classification.riskLevel,
        reasons: overrides.reasons,
      },
      decision: {
        baseClass,
        finalClass,
        confidence,
        matchedRules,
        overrideApplied: overrides.minClass !== null,
        overrideReasons: overrides.reasons,
      },
      protectionActions,
      policy,
    });
    
  } catch (error) {
    console.error('Error classifying data:', error);
    return NextResponse.json({ error: 'Failed to classify data' }, { status: 500 });
  }
}
