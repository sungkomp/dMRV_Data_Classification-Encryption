import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const policies = await db.protectionPolicy.findMany({
      include: {
        classification: true
      },
      orderBy: { classificationId: 'asc' }
    });
    
    return NextResponse.json(policies);
  } catch (error) {
    console.error('Error fetching policies:', error);
    return NextResponse.json({ error: 'Failed to fetch policies' }, { status: 500 });
  }
}
