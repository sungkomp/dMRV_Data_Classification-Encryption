import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const simulationData = await db.simulationData.findMany({
      orderBy: [{ dataType: 'asc' }, { name: 'asc' }]
    });
    
    return NextResponse.json(simulationData);
  } catch (error) {
    console.error('Error fetching simulation data:', error);
    return NextResponse.json({ error: 'Failed to fetch simulation data' }, { status: 500 });
  }
}
