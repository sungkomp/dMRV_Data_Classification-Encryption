import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// In-memory simulation state
let simulationInterval: NodeJS.Timeout | null = null;
let isRunning = false;
let classificationCount = 0;

// Data source configurations
const dataSources = [
  {
    type: 'sensor',
    name: 'Methane Sensor',
    riskRange: { min: 15, max: 40 },
  },
  {
    type: 'sensor',
    name: 'Soil Moisture Sensor',
    riskRange: { min: 8, max: 20 },
  },
  {
    type: 'lidar',
    name: 'Forest LiDAR Scanner',
    riskRange: { min: 30, max: 48 },
  },
  {
    type: 'satellite',
    name: 'Sentinel-2 Imagery',
    riskRange: { min: 8, max: 22 },
  },
  {
    type: 'drone',
    name: 'Drone Survey',
    riskRange: { min: 18, max: 35 },
  },
  {
    type: 'evidence',
    name: 'Verification Document',
    riskRange: { min: 35, max: 50 },
  },
];

// Risk score generators - generates scores that sum to approximately target
function generateRiskScores(totalTarget: number) {
  // Use 9 factors to match schema
  const factors = [
    'piiScore', 
    'geospatialScore', 
    'carbonCriticality', 
    'evidenceValue',
    'legalScore', 
    'businessScore', 
    'integrityScore', 
    'availabilityScore', 
    'securityScore',
  ];
  
  const scores: Record<string, number> = {};
  let remaining = totalTarget;
  
  factors.forEach((factor, index) => {
    if (index === factors.length - 1) {
      scores[factor] = Math.min(5, Math.max(0, remaining));
    } else {
      const max = Math.min(5, remaining);
      const min = Math.max(0, remaining - (factors.length - index - 1) * 5);
      scores[factor] = Math.floor(Math.random() * (max - min + 1)) + min;
      remaining -= scores[factor];
    }
  });
  
  return scores;
}

// Classification logic
function calculateClassification(totalScore: number): string {
  if (totalScore <= 8) return 'C1';
  if (totalScore <= 15) return 'C2';
  if (totalScore <= 24) return 'C3';
  if (totalScore <= 35) return 'C4';
  return 'C5';
}

function applyOverrides(scores: Record<string, number>): { minClass: string | null; rules: string[] } {
  const matchedRules: string[] = [];
  let minClass: string | null = null;

  if (scores.piiScore >= 4) {
    matchedRules.push('R01');
    minClass = 'C4';
  }

  if (scores.piiScore >= 4 && scores.geospatialScore >= 4) {
    matchedRules.push('R02');
    minClass = 'C4';
  }

  if (scores.carbonCriticality >= 5) {
    matchedRules.push('R03');
    if (!minClass || minClass < 'C4') minClass = 'C4';
  }

  if (scores.evidenceValue >= 5) {
    matchedRules.push('R04');
    if (!minClass || minClass < 'C5') minClass = 'C5';
  }

  if (scores.evidenceValue >= 5 && scores.integrityScore >= 5) {
    matchedRules.push('R06');
    minClass = 'C5';
  }

  if (scores.securityScore >= 4) {
    matchedRules.push('R09');
    if (!minClass || minClass < 'C4') minClass = 'C4';
  }

  return { minClass, rules: matchedRules };
}

// Single classification step
async function runClassificationStep() {
  try {
    // Pick random source
    const source = dataSources[Math.floor(Math.random() * dataSources.length)];
    
    // Get classification levels
    const levels = await db.classificationLevel.findMany();
    const levelMap = new Map(levels.map(l => [l.code, l]));
    
    // Generate risk scores
    const targetScore = Math.floor(
      Math.random() * (source.riskRange.max - source.riskRange.min + 1) + source.riskRange.min
    );
    const riskScores = generateRiskScores(targetScore);
    const totalScore = Object.values(riskScores).reduce((a, b) => a + b, 0);
    
    // Calculate classification
    const baseClass = calculateClassification(totalScore);
    const overrides = applyOverrides(riskScores);
    
    let finalClass = baseClass;
    if (overrides.minClass) {
      const classOrder = ['C1', 'C2', 'C3', 'C4', 'C5'];
      const baseIndex = classOrder.indexOf(baseClass);
      const overrideIndex = classOrder.indexOf(overrides.minClass);
      if (overrideIndex > baseIndex) {
        finalClass = overrides.minClass;
      }
    }
    
    const confidence = Math.min(0.5 + overrides.rules.length * 0.1 + Math.random() * 0.3, 0.99);
    const level = levelMap.get(finalClass);
    
    // Generate asset name
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const assetName = `${source.name.replace(/\s+/g, '_')}_${timestamp}_${++classificationCount}`;
    
    // Create asset in database using correct field names from schema
    const asset = await db.asset.create({
      data: {
        name: assetName,
        sourceType: source.type,
        classificationId: level?.id,
        confidence,
        decisionSource: overrides.rules.length > 0 ? 'rules+risk' : 'risk',
        piiScore: riskScores.piiScore,
        geospatialScore: riskScores.geospatialScore,
        carbonCriticality: riskScores.carbonCriticality,
        evidenceValue: riskScores.evidenceValue,
        legalScore: riskScores.legalScore,
        businessScore: riskScores.businessScore,
        integrityScore: riskScores.integrityScore,
        availabilityScore: riskScores.availabilityScore,
        securityScore: riskScores.securityScore,
        totalRiskScore: totalScore,
        workflowState: 'raw',
      },
    });
    
    // Create audit record
    await db.auditRecord.create({
      data: {
        assetId: asset.id,
        eventType: 'classify',
        actor: 'Simulation Engine',
        actorType: 'system',
        description: `Auto-classified as ${finalClass} with ${(confidence * 100).toFixed(1)}% confidence`,
        newClassification: finalClass,
        decisionTrace: JSON.stringify({
          totalScore,
          baseClass,
          finalClass,
          matchedRules: overrides.rules,
          confidence,
        }),
      },
    });
    
    console.log(`📊 [${source.type}] ${assetName} → ${finalClass} (${(confidence * 100).toFixed(1)}%)`);
    
  } catch (error) {
    console.error('Classification step error:', error);
  }
}

export async function GET() {
  return NextResponse.json({ 
    running: isRunning,
    count: classificationCount,
    message: isRunning ? 'Simulation is running' : 'Simulation is stopped'
  });
}

export async function POST() {
  try {
    if (isRunning) {
      return NextResponse.json({ 
        success: true, 
        message: 'Simulation already running',
        running: true,
        count: classificationCount
      });
    }
    
    isRunning = true;
    
    // Run classification every 2-4 seconds
    simulationInterval = setInterval(async () => {
      if (!isRunning) {
        if (simulationInterval) {
          clearInterval(simulationInterval);
          simulationInterval = null;
        }
        return;
      }
      await runClassificationStep();
    }, 2000 + Math.random() * 2000);
    
    // Run first classification immediately
    await runClassificationStep();
    
    return NextResponse.json({ 
      success: true, 
      message: 'Simulation started',
      running: true,
      count: classificationCount
    });
  } catch (error) {
    console.error('Failed to start simulation:', error);
    return NextResponse.json({ 
      success: false, 
      message: 'Failed to start simulation',
      running: false 
    }, { status: 500 });
  }
}

export async function DELETE() {
  isRunning = false;
  if (simulationInterval) {
    clearInterval(simulationInterval);
    simulationInterval = null;
  }
  return NextResponse.json({ 
    success: true, 
    message: 'Simulation stopped',
    running: false,
    count: classificationCount
  });
}
