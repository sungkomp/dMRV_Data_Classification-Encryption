import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    // Get recent classifications
    const recentAssets = await db.asset.findMany({
      where: {
        classificationId: { not: null }
      },
      include: {
        classification: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    // Calculate stats
    const stats = {
      total: recentAssets.length,
      c1: recentAssets.filter(a => a.classification?.code === 'C1').length,
      c2: recentAssets.filter(a => a.classification?.code === 'C2').length,
      c3: recentAssets.filter(a => a.classification?.code === 'C3').length,
      c4: recentAssets.filter(a => a.classification?.code === 'C4').length,
      c5: recentAssets.filter(a => a.classification?.code === 'C5').length,
    };

    // Get recent audit records
    const recentAudit = await db.auditRecord.findMany({
      where: {
        eventType: 'classify'
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    // Combine data
    const events = recentAssets.map(asset => {
      const audit = recentAudit.find(a => a.assetId === asset.id);
      let matchedRules: string[] = [];
      if (audit?.decisionTrace) {
        try {
          const trace = JSON.parse(audit.decisionTrace);
          matchedRules = trace.matchedRules || [];
        } catch {
          matchedRules = [];
        }
      }
      
      return {
        id: asset.id,
        assetId: asset.id,
        assetName: asset.name,
        sourceType: asset.sourceType,
        classification: asset.classification?.code || 'N/A',
        classificationName: asset.classification?.name || 'Unknown',
        classificationColor: asset.classification?.color || '#888',
        confidence: asset.confidence || 0,
        totalScore: asset.totalRiskScore,
        riskScores: {
          piiScore: asset.piiScore,
          geospatialScore: asset.geospatialScore,
          carbonCriticality: asset.carbonCriticality,
          evidenceValue: asset.evidenceValue,
          legalScore: asset.legalScore,
          businessScore: asset.businessScore,
          integrityScore: asset.integrityScore,
          availabilityScore: asset.availabilityScore,
          securityScore: asset.securityScore,
        },
        matchedRules,
        timestamp: asset.createdAt.toISOString(),
      };
    });

    return NextResponse.json({
      events,
      stats,
      lastUpdate: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Error fetching simulation events:', error);
    return NextResponse.json({ error: 'Failed to fetch events' }, { status: 500 });
  }
}
