import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const levels = await db.classificationLevel.findMany({
      include: {
        _count: {
          select: { assets: true, policies: true }
        }
      },
      orderBy: { code: 'asc' }
    });
    
    return NextResponse.json(levels);
  } catch (error) {
    console.error('Error fetching classification levels:', error);
    return NextResponse.json({ error: 'Failed to fetch classification levels' }, { status: 500 });
  }
}
