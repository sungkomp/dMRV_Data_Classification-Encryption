import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const rules = await db.classificationRule.findMany({
      orderBy: { priority: 'desc' }
    });
    
    return NextResponse.json(rules);
  } catch (error) {
    console.error('Error fetching classification rules:', error);
    return NextResponse.json({ error: 'Failed to fetch classification rules' }, { status: 500 });
  }
}
