import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const reasons = await db.riskReason.findMany({
      orderBy: { code: 'asc' }
    });
    
    return NextResponse.json(reasons);
  } catch (error) {
    console.error('Error fetching risk reasons:', error);
    return NextResponse.json({ error: 'Failed to fetch risk reasons' }, { status: 500 });
  }
}
