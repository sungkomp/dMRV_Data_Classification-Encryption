'use client';

import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Shield,
  LayoutDashboard,
  Table2,
  Calculator,
  GitBranch,
  Database,
  Lock,
  FileText,
  Github,
  ExternalLink,
  Activity,
  Server
} from 'lucide-react';
import { DashboardOverview } from '@/components/dmrv/DashboardOverview';
import { ClassificationMatrix } from '@/components/dmrv/ClassificationMatrix';
import { RiskCalculator } from '@/components/dmrv/RiskCalculator';
import { ArchitectureView } from '@/components/dmrv/ArchitectureView';
import { DataSourcesView } from '@/components/dmrv/DataSourcesView';
import { ProtectionPolicies } from '@/components/dmrv/ProtectionPolicies';
import { LiveSimulationDashboard } from '@/components/dmrv/LiveSimulationDashboard';

export default function DMRVClassificationSystem() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-gradient-to-br from-primary to-primary/60">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">dMRV Classification System</h1>
              <p className="text-xs text-muted-foreground">Auto Data Classification & Encryption Engine</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="hidden sm:flex">
              <Activity className="h-3 w-3 mr-1 text-green-500" />
              System Active
            </Badge>
            <Badge variant="secondary" className="hidden sm:flex">
              <Server className="h-3 w-3 mr-1" />
              Simulation Mode
            </Badge>
            <Button variant="outline" size="sm" asChild>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                <Github className="h-4 w-4 mr-2" />
                GitHub
                <ExternalLink className="h-3 w-3 ml-1" />
              </a>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 h-auto">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="simulation" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              <span className="hidden sm:inline">Simulation</span>
            </TabsTrigger>
            <TabsTrigger value="classification" className="flex items-center gap-2">
              <Table2 className="h-4 w-4" />
              <span className="hidden sm:inline">Classification</span>
            </TabsTrigger>
            <TabsTrigger value="calculator" className="flex items-center gap-2">
              <Calculator className="h-4 w-4" />
              <span className="hidden sm:inline">Calculator</span>
            </TabsTrigger>
            <TabsTrigger value="architecture" className="flex items-center gap-2">
              <GitBranch className="h-4 w-4" />
              <span className="hidden sm:inline">Architecture</span>
            </TabsTrigger>
            <TabsTrigger value="datasources" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              <span className="hidden sm:inline">Sources</span>
            </TabsTrigger>
            <TabsTrigger value="policies" className="flex items-center gap-2">
              <Lock className="h-4 w-4" />
              <span className="hidden sm:inline">Policies</span>
            </TabsTrigger>
            <TabsTrigger value="docs" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Docs</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <DashboardOverview />
          </TabsContent>

          <TabsContent value="simulation">
            <LiveSimulationDashboard />
          </TabsContent>

          <TabsContent value="classification">
            <ClassificationMatrix />
          </TabsContent>

          <TabsContent value="calculator">
            <RiskCalculator />
          </TabsContent>

          <TabsContent value="architecture">
            <ArchitectureView />
          </TabsContent>

          <TabsContent value="datasources">
            <DataSourcesView />
          </TabsContent>

          <TabsContent value="policies">
            <ProtectionPolicies />
          </TabsContent>

          <TabsContent value="docs">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Data Classification Policy */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Data Classification Policy
                  </CardTitle>
                  <CardDescription>
                    นโยบายการจัดชั้นข้อมูลสำหรับระบบ dMRV
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">วัตถุประสงค์ (Purpose)</h4>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc pl-4">
                      <li>ปกป้องความลับของข้อมูลโครงการคาร์บอน</li>
                      <li>ป้องกันการปลอมแปลงข้อมูล (Carbon Credit Fraud)</li>
                      <li>รองรับ audit / verification / certification</li>
                      <li>สนับสนุนการปฏิบัติตามมาตรฐานความปลอดภัยข้อมูล</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">ขอบเขต (Scope)</h4>
                    <p className="text-sm text-muted-foreground">
                      ครอบคลุมข้อมูลทั้งหมดในระบบ dMRV: Sensor/IoT, LiDAR, Satellite, Drone, 
                      Field Survey, Human Evidence, Emission Calculation, Carbon Report
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Risk Factors */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Risk Factors & Controls
                  </CardTitle>
                  <CardDescription>
                    ปัจจัยความเสี่ยงและมาตรการควบคุม
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">ปัจจัยความเสี่ยงหลัก</h4>
                    <div className="grid gap-2">
                      {[
                        { risk: 'Data Integrity', control: 'Checksum, Digital Signature, Immutable Storage' },
                        { risk: 'Privacy Exposure', control: 'Field Encryption, Tokenization, Masking' },
                        { risk: 'Carbon Fraud', control: 'Multi-source Verification, Audit Trail, Chain of Custody' },
                        { risk: 'Unauthorized Access', control: 'RBAC, MFA, Access Logging' },
                      ].map((item, i) => (
                        <div key={i} className="p-2 rounded bg-muted/50">
                          <p className="text-sm font-medium">{item.risk}</p>
                          <p className="text-xs text-muted-foreground">{item.control}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Data Handling */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Data Handling Requirements
                  </CardTitle>
                  <CardDescription>
                    ข้อกำหนดการจัดการข้อมูลตามระดับการจัดชั้น
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Control</th>
                          <th className="text-center p-2">C1</th>
                          <th className="text-center p-2">C2</th>
                          <th className="text-center p-2">C3</th>
                          <th className="text-center p-2">C4</th>
                          <th className="text-center p-2">C5</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          ['Encryption', 'Optional', 'Recommended', 'Required', 'Required', 'Required'],
                          ['Access Control', 'Open', 'Auth', 'RBAC', 'Strict RBAC', 'Dual Control'],
                          ['Audit Log', 'No', 'Optional', 'Required', 'Mandatory', 'Mandatory'],
                          ['Immutable Storage', 'No', 'No', 'Optional', 'Required', 'Required'],
                        ].map((row, i) => (
                          <tr key={i} className="border-b">
                            {row.map((cell, j) => (
                              <td key={j} className={`p-2 ${j === 0 ? 'font-medium' : 'text-center'}`}>
                                {cell === 'Required' || cell === 'Mandatory' ? (
                                  <Badge variant="default" className="text-xs">{cell}</Badge>
                                ) : cell === 'Optional' || cell === 'Recommended' ? (
                                  <Badge variant="outline" className="text-xs">{cell}</Badge>
                                ) : (
                                  cell
                                )}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Retention Policy */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Retention Policy
                  </CardTitle>
                  <CardDescription>
                    นโยบายการเก็บรักษาข้อมูล
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { type: 'Raw Telemetry', retention: '5-7 years' },
                    { type: 'Satellite Imagery', retention: '3-5 years' },
                    { type: 'Drone Imagery', retention: '5 years' },
                    { type: 'LiDAR Evidence', retention: '10 years' },
                    { type: 'Audit Evidence', retention: '7-10 years' },
                    { type: 'Security Logs', retention: '1-3 years' },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-2 rounded bg-muted/50">
                      <span className="text-sm font-medium">{item.type}</span>
                      <Badge variant="secondary">{item.retention}</Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="sticky bottom-0 mt-auto border-t bg-background py-4">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            dMRV Auto Classification & Encryption System v1.0.0
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>ISO/IEC 27001:2022 Compliant</span>
            <span>•</span>
            <span>NIST CSF 2.0 Aligned</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
