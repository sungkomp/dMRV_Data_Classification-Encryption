'use client';

import { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Database,
  ArrowRight,
  Search,
  Shield,
  Lock,
  FileCheck,
  Server,
  Cloud,
  Eye,
  Settings,
  GitBranch,
  Activity,
  Cpu,
  HardDrive,
  AlertTriangle,
  Zap,
  Layers,
  Box
} from 'lucide-react';

interface Layer {
  id: string;
  name: string;
  nameTh: string;
  icon: React.ReactNode;
  description: string;
  components: string[];
  color: string;
}

const architectureLayers: Layer[] = [
  {
    id: 'layer1',
    name: 'Data Ingress & Event Trigger',
    nameTh: 'การรับข้อมูลและทริกเกอร์',
    icon: <Database className="h-5 w-5" />,
    description: 'Receives events when new data enters the system',
    components: ['Streaming telemetry', 'File upload', 'API ingestion', 'Database insert', 'Document submission', 'Remote sensing batch'],
    color: '#3B82F6',
  },
  {
    id: 'layer2',
    name: 'Data Discovery & Extraction',
    nameTh: 'ค้นหาและสกัดข้อมูล',
    icon: <Search className="h-5 w-5" />,
    description: 'Extracts metadata, content, and context from data',
    components: ['Metadata Extractor', 'Content Extractor', 'OCR/NLP', 'Geospatial Extractor', 'Context Extractor'],
    color: '#06B6D4',
  },
  {
    id: 'layer3',
    name: 'Core Decision Engine',
    nameTh: 'เครื่องมือตัดสินใจหลัก',
    icon: <Cpu className="h-5 w-5" />,
    description: 'Makes classification decisions using rules, ML, and risk scoring',
    components: ['Rule Engine', 'ML/NLP Classifier', 'Risk Scoring Engine', 'Decision Aggregator', 'Policy Override'],
    color: '#8B5CF6',
  },
  {
    id: 'layer4',
    name: 'Policy Orchestration',
    nameTh: 'ประสานนโยบาย',
    icon: <Settings className="h-5 w-5" />,
    description: 'Maps classification to protection policies and controls',
    components: ['Policy Mapper', 'Encryption Orchestrator', 'Tokenization Service', 'Key Management', 'Vault Handler'],
    color: '#EC4899',
  },
  {
    id: 'layer5',
    name: 'Trust & Audit Layer',
    nameTh: 'ความน่าเชื่อถือและการตรวจสอบ',
    icon: <FileCheck className="h-5 w-5" />,
    description: 'Maintains classification registry and audit trails',
    components: ['Classification Registry', 'Evidence Integrity', 'Audit Log Service', 'Lineage Catalog'],
    color: '#F59E0B',
  },
  {
    id: 'layer6',
    name: 'Human Review & Governance',
    nameTh: 'การตรวจสอบและธรรมาภิบาล',
    icon: <Eye className="h-5 w-5" />,
    description: 'Enables manual review and policy administration',
    components: ['Review Workbench', 'Exception Management', 'Policy Console', 'Model Governance'],
    color: '#EF4444',
  },
  {
    id: 'layer7',
    name: 'Integration Layer',
    nameTh: 'การเชื่อมต่อ',
    icon: <GitBranch className="h-5 w-5" />,
    description: 'Connects with storage, databases, and external systems',
    components: ['Object Storage', 'Data Lakehouse', 'DBMS', 'API Gateway', 'SIEM', 'IAM/KMS'],
    color: '#10B981',
  },
];

interface DataFlow {
  title: string;
  steps: string[];
}

const dataFlows: DataFlow[] = [
  {
    title: 'Document Verification Upload',
    steps: [
      'User uploads PDF verification document',
      'Ingress service creates asset_id',
      'Metadata/Content extractor reads OCR, signature, keywords',
      'Rule engine detects verification/signed/approved keywords',
      'Workflow context indicates approval stage',
      'Risk engine assigns high integrity/auditability scores',
      'Decision aggregator classifies as C5',
      'Policy mapper selects immutable storage + encryption + signature validation',
      'Orchestrator moves file to evidence vault',
      'Registry records decision rationale and audit trail',
    ],
  },
  {
    title: 'Sensor Methane Data Stream',
    steps: [
      'Gateway sends telemetry',
      'Stream event enters classifier',
      'Extractor reads device type, parameter code, project context',
      'Context service identifies stream used in calculation engine',
      'Rule engine marks as C4 candidate',
      'Risk engine assigns high integrity score',
      'Policy enforces signed ingest, strong encryption, append-only archive',
      'Curated view for analyst has reduced exposure via masking/role filter',
    ],
  },
  {
    title: 'Public Report After Release',
    steps: [
      'Report draft was originally C3',
      'Workflow event "release_approved=true" received',
      'Reclassification trigger activates',
      'Decision engine changes final published copy to C1',
      'Draft copy remains C3 in archive',
      'Published copy uses standard protection profile',
    ],
  },
];

export function ArchitectureView() {
  const [selectedLayer, setSelectedLayer] = useState<Layer | null>(null);
  const [selectedFlow, setSelectedFlow] = useState<DataFlow | null>(null);
  const [activeStep, setActiveStep] = useState(0);

  return (
    <div className="space-y-6">
      {/* Architecture Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Layers className="h-5 w-5" />
            Auto Classification & Encryption Engine Architecture
          </CardTitle>
          <CardDescription>
            7-layer architecture designed for dMRV data protection
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {architectureLayers.map((layer, index) => (
              <div key={layer.id}>
                <Card 
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedLayer?.id === layer.id ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => setSelectedLayer(selectedLayer?.id === layer.id ? null : layer)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div 
                        className="p-3 rounded-lg text-white"
                        style={{ backgroundColor: layer.color }}
                      >
                        {layer.icon}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-muted-foreground">
                            Layer {index + 1}
                          </span>
                          <h3 className="font-semibold">{layer.name}</h3>
                        </div>
                        <p className="text-xs text-muted-foreground">{layer.nameTh}</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          {layer.description}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-1 max-w-xs">
                        {layer.components.slice(0, 3).map((comp, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {comp}
                          </Badge>
                        ))}
                        {layer.components.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{layer.components.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {index < architectureLayers.length - 1 && (
                  <div className="flex justify-center py-1">
                    <ArrowRight className="h-4 w-4 text-muted-foreground rotate-90" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Selected Layer Details */}
      {selectedLayer && (
        <Card style={{ borderColor: selectedLayer.color, borderWidth: 2 }}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div 
                className="p-2 rounded-lg text-white"
                style={{ backgroundColor: selectedLayer.color }}
              >
                {selectedLayer.icon}
              </div>
              {selectedLayer.name}
            </CardTitle>
            <CardDescription>{selectedLayer.nameTh}</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">{selectedLayer.description}</p>
            <div>
              <h4 className="font-semibold mb-2">Components:</h4>
              <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
                {selectedLayer.components.map((comp, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 rounded bg-muted/50">
                    <Box className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{comp}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Data Flow Simulations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            End-to-End Data Flow Simulations
          </CardTitle>
          <CardDescription>
            Step-by-step classification and protection flows for different data types
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3 mb-6">
            {dataFlows.map((flow, i) => (
              <Card 
                key={i}
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedFlow?.title === flow.title ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => {
                  setSelectedFlow(flow);
                  setActiveStep(0);
                }}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Zap className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">{flow.title}</h4>
                      <p className="text-xs text-muted-foreground">
                        {flow.steps.length} steps
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {selectedFlow && (
            <div className="space-y-2">
              <h4 className="font-semibold mb-4">{selectedFlow.title}</h4>
              <div className="relative">
                {selectedFlow.steps.map((step, i) => (
                  <div key={i} className="flex gap-4 mb-3">
                    <div className="flex flex-col items-center">
                      <div 
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                          i <= activeStep 
                            ? 'bg-primary text-white' 
                            : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        {i + 1}
                      </div>
                      {i < selectedFlow.steps.length - 1 && (
                        <div className={`w-0.5 h-full min-h-6 ${
                          i < activeStep ? 'bg-primary' : 'bg-muted'
                        }`} />
                      )}
                    </div>
                    <div className={`flex-1 p-3 rounded-lg ${
                      i === activeStep ? 'bg-primary/10 border border-primary' : 'bg-muted/50'
                    }`}>
                      <p className="text-sm">{step}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 justify-end mt-4">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setActiveStep(Math.max(0, activeStep - 1))}
                  disabled={activeStep === 0}
                >
                  Previous
                </Button>
                <Button 
                  size="sm"
                  onClick={() => setActiveStep(Math.min(selectedFlow.steps.length - 1, activeStep + 1))}
                  disabled={activeStep === selectedFlow.steps.length - 1}
                >
                  Next
                </Button>
                <Button 
                  variant="secondary"
                  size="sm"
                  onClick={() => setActiveStep(0)}
                >
                  Reset
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Key Principles */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Shield className="h-4 w-4" />
              Design Principles
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { title: 'Hybrid Decision', desc: 'Uses both Rule-based and ML/NLP classification' },
              { title: 'Context-aware', desc: 'Same file may get different labels based on workflow state' },
              { title: 'Explainable by Design', desc: 'Every result includes label, score, policy, reasons' },
              { title: 'Enforcement by Orchestration', desc: 'Classification triggers actual controls' },
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-3 p-2 rounded-lg bg-muted/50">
                <Zap className="h-4 w-4 text-amber-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">{item.title}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="h-4 w-4" />
              Security Architecture
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { title: 'Zero Trust', desc: 'mTLS between services, least privilege IAM' },
              { title: 'Key Separation', desc: 'Separate key domains for C1-C3 vs C4-C5' },
              { title: 'Tamper Protection', desc: 'Append-only audit logs, signed policies' },
              { title: 'Segregation of Duties', desc: 'Policy admin, Security admin, Reviewer roles' },
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-3 p-2 rounded-lg bg-muted/50">
                <Lock className="h-4 w-4 text-red-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">{item.title}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
