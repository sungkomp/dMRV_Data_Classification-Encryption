'use client';

import { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Shield, 
  Database, 
  FileCheck, 
  AlertTriangle, 
  Lock, 
  Activity,
  TrendingUp,
  Server,
  Eye
} from 'lucide-react';

interface ClassificationLevel {
  id: string;
  code: string;
  name: string;
  nameTh: string;
  description: string;
  descriptionTh: string | null;
  riskLevel: string;
  color: string;
  _count: {
    assets: number;
    policies: number;
  };
}

interface Stats {
  totalAssets: number;
  classifiedAssets: number;
  pendingReview: number;
  protectionActions: number;
}

export function DashboardOverview() {
  const [levels, setLevels] = useState<ClassificationLevel[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalAssets: 0,
    classifiedAssets: 0,
    pendingReview: 0,
    protectionActions: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const levelsRes = await fetch('/api/classification/levels');
        const levelsData = await levelsRes.json();
        setLevels(levelsData);

        const assetsRes = await fetch('/api/assets');
        const assetsData = await assetsRes.json();
        
        setStats({
          totalAssets: assetsData.length,
          classifiedAssets: assetsData.filter((a: { classificationId: string | null }) => a.classificationId).length,
          pendingReview: Math.floor(Math.random() * 5) + 2,
          protectionActions: Math.floor(Math.random() * 20) + 10,
        });
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="pb-2">
              <div className="h-4 w-24 bg-muted rounded" />
            </CardHeader>
            <CardContent>
              <div className="h-8 w-16 bg-muted rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Assets</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalAssets}</div>
            <p className="text-xs text-muted-foreground">Data items in system</p>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Classified</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.classifiedAssets}</div>
            <Progress value={(stats.classifiedAssets / Math.max(stats.totalAssets, 1)) * 100} className="mt-2 h-2" />
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingReview}</div>
            <p className="text-xs text-muted-foreground">Awaiting manual review</p>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Protection Actions</CardTitle>
            <Lock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.protectionActions}</div>
            <p className="text-xs text-muted-foreground">Encryption & controls applied</p>
          </CardContent>
        </Card>
      </div>

      {/* Classification Levels Grid */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Classification Levels
          </CardTitle>
          <CardDescription>
            Data classification hierarchy based on sensitivity and risk
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-5">
            {levels.map((level) => (
              <Card 
                key={level.id} 
                className="relative overflow-hidden"
                style={{ borderLeftColor: level.color, borderLeftWidth: 4 }}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Badge 
                      style={{ backgroundColor: level.color }}
                      className="text-white font-bold"
                    >
                      {level.code}
                    </Badge>
                    <span className="text-2xl font-bold">{level._count.assets}</span>
                  </div>
                  <h3 className="font-semibold">{level.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{level.nameTh}</p>
                  <Badge variant="outline" className="mt-2 text-xs">
                    {level.riskLevel} Risk
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* System Architecture Overview */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="h-4 w-4 text-blue-500" />
              Classification Pipeline
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { step: 'Data Ingestion', status: 'active', icon: Database },
              { step: 'Feature Extraction', status: 'active', icon: FileCheck },
              { step: 'Risk Assessment', status: 'active', icon: AlertTriangle },
              { step: 'Classification', status: 'active', icon: Shield },
              { step: 'Protection Enforcement', status: 'active', icon: Lock },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                <div className="p-1.5 rounded-full bg-green-500/20">
                  <item.icon className="h-3.5 w-3.5 text-green-600" />
                </div>
                <span className="text-sm">{item.step}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Server className="h-4 w-4 text-purple-500" />
              Data Sources
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { type: 'Sensor/IoT', count: 15, color: 'bg-blue-500' },
              { type: 'LiDAR', count: 8, color: 'bg-purple-500' },
              { type: 'Satellite', count: 12, color: 'bg-cyan-500' },
              { type: 'Drone', count: 6, color: 'bg-orange-500' },
              { type: 'Evidence', count: 10, color: 'bg-red-500' },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${item.color}`} />
                  <span className="text-sm">{item.type}</span>
                </div>
                <Badge variant="secondary">{item.count}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-green-500" />
              Protection Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Encrypted at Rest</span>
                <span className="font-medium">92%</span>
              </div>
              <Progress value={92} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Encryption in Transit</span>
                <span className="font-medium">100%</span>
              </div>
              <Progress value={100} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Access Controls</span>
                <span className="font-medium">88%</span>
              </div>
              <Progress value={88} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Immutable Storage</span>
                <span className="font-medium">75%</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
