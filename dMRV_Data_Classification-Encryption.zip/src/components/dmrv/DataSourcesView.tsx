'use client';

import { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Database,
  Radio,
  Satellite,
  Plane,
  FileText,
  Shield,
  Server,
  Activity,
  Clock,
  User,
  AlertTriangle,
  CheckCircle,
  Eye,
  Copy,
  Download
} from 'lucide-react';

interface SimulationItem {
  id: string;
  name: string;
  dataType: string;
  sampleData: string;
  expectedClass: string;
  riskFactors: string;
  description: string | null;
}

interface AuditLog {
  id: string;
  eventType: string;
  actor: string;
  actorType: string;
  description: string;
  oldClassification: string | null;
  newClassification: string | null;
  createdAt: string;
  asset: {
    name: string;
    sourceType: string;
  };
}

const dataTypeIcons: Record<string, React.ReactNode> = {
  sensor: <Radio className="h-4 w-4" />,
  iot: <Radio className="h-4 w-4" />,
  lidar: <Database className="h-4 w-4" />,
  satellite: <Satellite className="h-4 w-4" />,
  drone: <Plane className="h-4 w-4" />,
  evidence: <FileText className="h-4 w-4" />,
  document: <FileText className="h-4 w-4" />,
  database: <Server className="h-4 w-4" />,
};

const classificationColors: Record<string, string> = {
  C1: '#22C55E',
  C2: '#3B82F6',
  C3: '#F59E0B',
  C4: '#EF4444',
  C5: '#7C3AED',
};

const classificationLabels: Record<string, string> = {
  C1: 'Public',
  C2: 'Internal',
  C3: 'Confidential',
  C4: 'Restricted',
  C5: 'Evidence-Critical',
};

export function DataSourcesView() {
  const [simulationData, setSimulationData] = useState<SimulationItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<SimulationItem | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('sources');

  useEffect(() => {
    async function fetchData() {
      try {
        const [simRes, assetsRes] = await Promise.all([
          fetch('/api/simulation'),
          fetch('/api/assets'),
        ]);
        const simData = await simRes.json();
        const assetsData = await assetsRes.json();
        
        setSimulationData(simData);
        
        // Create mock audit logs from assets
        const logs: AuditLog[] = assetsData.flatMap((asset: { 
          id: string; 
          name: string; 
          sourceType: string;
          classification: { code: string } | null;
          createdAt: string;
        }) => ({
          id: asset.id,
          eventType: 'classify',
          actor: 'Auto Classification Engine',
          actorType: 'system',
          description: `Classified ${asset.name} as ${asset.classification?.code || 'N/A'}`,
          oldClassification: null,
          newClassification: asset.classification?.code || null,
          createdAt: asset.createdAt,
          asset: {
            name: asset.name,
            sourceType: asset.sourceType,
          },
        }));
        
        setAuditLogs(logs);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const groupedByType = simulationData.reduce((acc, item) => {
    if (!acc[item.dataType]) acc[item.dataType] = [];
    acc[item.dataType].push(item);
    return acc;
  }, {} as Record<string, SimulationItem[]>);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 w-48 bg-muted rounded" />
            <div className="h-64 bg-muted rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="sources">Data Sources</TabsTrigger>
          <TabsTrigger value="audit">Audit Trail</TabsTrigger>
        </TabsList>

        <TabsContent value="sources" className="space-y-4">
          {/* Summary Cards */}
          <div className="grid gap-4 md:grid-cols-5">
            {Object.entries(groupedByType).map(([type, items]) => (
              <Card key={type} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      {dataTypeIcons[type] || <Database className="h-4 w-4" />}
                    </div>
                    <div>
                      <p className="font-medium capitalize">{type}</p>
                      <p className="text-2xl font-bold">{items.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Data Sources Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Simulation Data Sources
              </CardTitle>
              <CardDescription>
                Sample data from various dMRV sources with expected classifications
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Expected Class</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {simulationData.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {dataTypeIcons[item.dataType]}
                          <Badge variant="outline" className="capitalize">
                            {item.dataType}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>
                        <Badge 
                          style={{ backgroundColor: classificationColors[item.expectedClass] }}
                          className="text-white"
                        >
                          {item.expectedClass}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs truncate text-muted-foreground">
                        {item.description}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setSelectedItem(item)}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="audit" className="space-y-4">
          {/* Audit Statistics */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Activity className="h-8 w-8 text-blue-500" />
                  <div>
                    <p className="text-sm text-muted-foreground">Total Events</p>
                    <p className="text-2xl font-bold">{auditLogs.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-8 w-8 text-green-500" />
                  <div>
                    <p className="text-sm text-muted-foreground">Classifications</p>
                    <p className="text-2xl font-bold">
                      {auditLogs.filter(l => l.eventType === 'classify').length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <User className="h-8 w-8 text-purple-500" />
                  <div>
                    <p className="text-sm text-muted-foreground">System Actions</p>
                    <p className="text-2xl font-bold">
                      {auditLogs.filter(l => l.actorType === 'system').length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Shield className="h-8 w-8 text-amber-500" />
                  <div>
                    <p className="text-sm text-muted-foreground">C4/C5 Items</p>
                    <p className="text-2xl font-bold">
                      {auditLogs.filter(l => l.newClassification === 'C4' || l.newClassification === 'C5').length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Audit Log Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Audit Log
              </CardTitle>
              <CardDescription>
                Complete trail of all classification and protection actions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Event</TableHead>
                      <TableHead>Asset</TableHead>
                      <TableHead>Classification</TableHead>
                      <TableHead>Actor</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="text-sm text-muted-foreground">
                          {new Date(log.createdAt).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {log.eventType}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {dataTypeIcons[log.asset.sourceType]}
                            <span className="font-medium">{log.asset.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {log.newClassification && (
                            <Badge 
                              style={{ backgroundColor: classificationColors[log.newClassification] }}
                              className="text-white"
                            >
                              {log.newClassification}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {log.actorType === 'system' ? (
                              <Activity className="h-4 w-4 text-blue-500" />
                            ) : (
                              <User className="h-4 w-4 text-purple-500" />
                            )}
                            <span className="text-sm">{log.actor}</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Detail Dialog */}
      <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedItem && dataTypeIcons[selectedItem.dataType]}
              {selectedItem?.name}
            </DialogTitle>
            <DialogDescription>
              Data source details and sample data
            </DialogDescription>
          </DialogHeader>
          
          {selectedItem && (
            <ScrollArea className="max-h-[60vh]">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Data Type</p>
                    <Badge variant="outline" className="capitalize mt-1">
                      {selectedItem.dataType}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Expected Classification</p>
                    <Badge 
                      style={{ backgroundColor: classificationColors[selectedItem.expectedClass] }}
                      className="text-white mt-1"
                    >
                      {selectedItem.expectedClass} - {classificationLabels[selectedItem.expectedClass]}
                    </Badge>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Description</p>
                  <p className="text-sm">{selectedItem.description}</p>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-muted-foreground">Sample Data</p>
                    <Button variant="ghost" size="sm">
                      <Copy className="h-4 w-4 mr-1" />
                      Copy
                    </Button>
                  </div>
                  <pre className="p-4 rounded-lg bg-muted overflow-x-auto text-xs">
                    {JSON.stringify(JSON.parse(selectedItem.sampleData), null, 2)}
                  </pre>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-2">Risk Factors</p>
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(JSON.parse(selectedItem.riskFactors)).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between p-2 rounded bg-muted/50">
                        <span className="text-sm capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                        <Badge variant="outline">{value as number}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
