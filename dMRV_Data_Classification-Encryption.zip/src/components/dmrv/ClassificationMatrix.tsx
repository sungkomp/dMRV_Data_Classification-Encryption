'use client';

import { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Info,
  Lock,
  Eye,
  Database,
  FileCheck
} from 'lucide-react';

interface ClassificationLevel {
  id: string;
  code: string;
  name: string;
  nameTh: string;
  description: string;
  descriptionTh: string | null;
  riskLevel: string;
  color: string;
}

export function ClassificationMatrix() {
  const [levels, setLevels] = useState<ClassificationLevel[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const res = await fetch('/api/classification/levels');
        const data = await res.json();
        setLevels(data);
      } catch (error) {
        console.error('Error fetching classification levels:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  // Risk scoring matrix data
  const riskFactors = [
    { name: 'PII / Personal Linkage', key: 'pii', description: 'ข้อมูลระบุตัวบุคคลหรือเชื่อมโยงส่วนบุคคล' },
    { name: 'Geospatial Sensitivity', key: 'geospatial', description: 'ความไวต่อพื้นที่/ที่ตั้ง' },
    { name: 'Carbon Criticality', key: 'carbon', description: 'ความสำคัญต่อการคำนวณคาร์บอน' },
    { name: 'Evidence Value', key: 'evidence', description: 'คุณค่าหลักฐานการตรวจสอบ' },
    { name: 'Legal / Contractual', key: 'legal', description: 'ข้อผูกพันทางกฎหมาย/สัญญา' },
    { name: 'Business Sensitivity', key: 'business', description: 'ความไวทางธุรกิจ' },
    { name: 'Integrity Impact', key: 'integrity', description: 'ผลกระทบต่อความถูกต้อง' },
    { name: 'Availability Impact', key: 'availability', description: 'ผลกระทบต่อความพร้อมใช้งาน' },
    { name: 'Traceability', key: 'traceability', description: 'ความต้องการพิสูจน์ย้อนหลัง' },
    { name: 'Security Exploitability', key: 'security', description: 'ความเสี่ยงด้านความปลอดภัย' },
  ];

  // Score to classification mapping
  const scoreRanges = [
    { range: '0-8', class: 'C1', label: 'Public' },
    { range: '9-15', class: 'C2', label: 'Internal' },
    { range: '16-24', class: 'C3', label: 'Confidential' },
    { range: '25-35', class: 'C4', label: 'Restricted' },
    { range: '36+', class: 'C5', label: 'Evidence-Critical' },
  ];

  const getScoreColor = (score: number): string => {
    if (score === 0) return 'bg-gray-100 text-gray-600';
    if (score <= 2) return 'bg-green-100 text-green-700';
    if (score <= 3) return 'bg-yellow-100 text-yellow-700';
    if (score <= 4) return 'bg-orange-100 text-orange-700';
    return 'bg-red-100 text-red-700';
  };

  const getRiskIcon = (level: string) => {
    switch (level) {
      case 'Low': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'Low-Medium': return <Info className="h-4 w-4 text-blue-500" />;
      case 'Medium-High': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'High': return <AlertTriangle className="h-4 w-4 text-orange-500" />;
      case 'Critical': return <Shield className="h-4 w-4 text-red-500" />;
      default: return <Info className="h-4 w-4 text-gray-500" />;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 w-48 bg-muted rounded" />
            <div className="h-64 bg-muted rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Classification Levels */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Data Classification Levels
          </CardTitle>
          <CardDescription>
            5-tier classification system for dMRV data based on sensitivity and risk
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-5">
            {levels.map((level) => (
              <Card 
                key={level.id} 
                className="overflow-hidden"
              >
                <div 
                  className="h-2" 
                  style={{ backgroundColor: level.color }}
                />
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge 
                      style={{ backgroundColor: level.color }}
                      className="text-white font-bold text-lg"
                    >
                      {level.code}
                    </Badge>
                    {getRiskIcon(level.riskLevel)}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{level.name}</h3>
                    <p className="text-sm text-muted-foreground">{level.nameTh}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">{level.description}</p>
                    <Badge variant="outline" className="text-xs">
                      {level.riskLevel} Risk
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Score to Classification Mapping */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Risk Score to Classification Mapping
          </CardTitle>
          <CardDescription>
            Total risk score determines base classification level
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {scoreRanges.map((range, i) => {
              const level = levels.find(l => l.code === range.class);
              return (
                <Card key={i} className="flex-1 min-w-[150px]">
                  <CardContent className="p-4 text-center">
                    <Badge 
                      style={{ backgroundColor: level?.color || '#888' }}
                      className="text-white font-bold mb-2"
                    >
                      {range.class}
                    </Badge>
                    <p className="font-semibold">{range.label}</p>
                    <p className="text-2xl font-bold mt-1">{range.range}</p>
                    <p className="text-xs text-muted-foreground">points</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Risk Scoring Matrix */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Risk Scoring Matrix
          </CardTitle>
          <CardDescription>
            Score each factor from 0-5 based on data characteristics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <TooltipProvider>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[200px]">Risk Factor</TableHead>
                  {[0, 1, 2, 3, 4, 5].map((score) => (
                    <TableHead key={score} className="text-center w-20">
                      {score}
                    </TableHead>
                  ))}
                  <TableHead className="text-center">Weight</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {riskFactors.map((factor) => (
                  <TableRow key={factor.key}>
                    <TableCell>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="cursor-help underline decoration-dotted">
                            {factor.name}
                          </span>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>{factor.description}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TableCell>
                    {[0, 1, 2, 3, 4, 5].map((score) => (
                      <TableCell key={score} className="text-center">
                        <Badge 
                          variant="outline" 
                          className={getScoreColor(score)}
                        >
                          {score}
                        </Badge>
                      </TableCell>
                    ))}
                    <TableCell className="text-center font-medium">
                      ×1
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TooltipProvider>
        </CardContent>
      </Card>

      {/* Override Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Override Rules
          </CardTitle>
          <CardDescription>
            These rules always apply regardless of score
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { condition: 'PII + Exact Geolocation detected', minClass: 'C4', color: '#EF4444' },
              { condition: 'Signed verification package detected', minClass: 'C5', color: '#7C3AED' },
              { condition: 'Approved calculation result for registry', minClass: 'C5', color: '#7C3AED' },
              { condition: 'Calibration certificate detected', minClass: 'C5', color: '#7C3AED' },
              { condition: 'Security credentials/keys detected', minClass: 'C4', color: '#EF4444' },
              { condition: 'Public report with release approval', minClass: 'C1', color: '#22C55E' },
            ].map((rule, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                  <span className="text-sm">{rule.condition}</span>
                </div>
                <Badge style={{ backgroundColor: rule.color }} className="text-white">
                  Min: {rule.minClass}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
