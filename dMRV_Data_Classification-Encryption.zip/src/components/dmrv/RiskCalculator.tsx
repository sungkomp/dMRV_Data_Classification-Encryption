'use client';

import { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Separator } from '@/components/ui/separator';
import {
  AlertTriangle,
  Shield,
  Calculator,
  PlayCircle,
  CheckCircle,
  Lock,
  Database,
  FileCheck,
  Zap,
  RefreshCw
} from 'lucide-react';

interface RiskScore {
  piiScore: number;
  geospatialScore: number;
  carbonCriticality: number;
  evidenceValue: number;
  legalScore: number;
  businessScore: number;
  integrityScore: number;
  availabilityScore: number;
  traceabilityScore: number;
  securityScore: number;
}

interface SimulationItem {
  id: string;
  name: string;
  dataType: string;
  sampleData: string;
  expectedClass: string;
  riskFactors: string;
  description: string | null;
}

const riskFactorsConfig = [
  { key: 'piiScore', label: 'PII / Personal Linkage', description: 'ข้อมูลระบุตัวบุคคล' },
  { key: 'geospatialScore', label: 'Geospatial Sensitivity', description: 'ความไวต่อพื้นที่' },
  { key: 'carbonCriticality', label: 'Carbon Criticality', description: 'ความสำคัญต่อคาร์บอน' },
  { key: 'evidenceValue', label: 'Evidence Value', description: 'คุณค่าหลักฐาน' },
  { key: 'legalScore', label: 'Legal / Contractual', description: 'ข้อผูกพันกฎหมาย' },
  { key: 'businessScore', label: 'Business Sensitivity', description: 'ความไวทางธุรกิจ' },
  { key: 'integrityScore', label: 'Integrity Impact', description: 'ผลกระทบความถูกต้อง' },
  { key: 'availabilityScore', label: 'Availability Impact', description: 'ผลกระทบความพร้อม' },
  { key: 'traceabilityScore', label: 'Traceability', description: 'ความต้องการพิสูจน์' },
  { key: 'securityScore', label: 'Security Exploitability', description: 'ความเสี่ยงความปลอดภัย' },
];

const classificationColors: Record<string, string> = {
  C1: '#22C55E',
  C2: '#3B82F6',
  C3: '#F59E0B',
  C4: '#EF4444',
  C5: '#7C3AED',
};

const classificationLabels: Record<string, string> = {
  C1: 'Public',
  C2: 'Internal',
  C3: 'Confidential',
  C4: 'Restricted',
  C5: 'Evidence-Critical',
};

export function RiskCalculator() {
  const [simulationData, setSimulationData] = useState<SimulationItem[]>([]);
  const [selectedData, setSelectedData] = useState<SimulationItem | null>(null);
  const [riskScores, setRiskScores] = useState<RiskScore>({
    piiScore: 0,
    geospatialScore: 0,
    carbonCriticality: 0,
    evidenceValue: 0,
    legalScore: 0,
    businessScore: 0,
    integrityScore: 0,
    availabilityScore: 0,
    traceabilityScore: 0,
    securityScore: 0,
  });
  const [result, setResult] = useState<{
    classification: string;
    confidence: number;
    totalScore: number;
    matchedRules: string[];
    protectionActions: string[];
  } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const res = await fetch('/api/simulation');
        const data = await res.json();
        setSimulationData(data);
      } catch (error) {
        console.error('Error fetching simulation data:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const calculateClassification = (totalScore: number): string => {
    if (totalScore <= 8) return 'C1';
    if (totalScore <= 15) return 'C2';
    if (totalScore <= 24) return 'C3';
    if (totalScore <= 35) return 'C4';
    return 'C5';
  };

  const applyOverrides = (scores: RiskScore): { minClass: string | null; rules: string[] } => {
    const matchedRules: string[] = [];
    let minClass: string | null = null;

    // R01: PII detection
    if (scores.piiScore >= 4) {
      matchedRules.push('R01');
      minClass = 'C4';
    }

    // R02: PII + Geospatial
    if (scores.piiScore >= 4 && scores.geospatialScore >= 4) {
      matchedRules.push('R02');
      minClass = 'C4';
    }

    // R03: Carbon critical
    if (scores.carbonCriticality >= 5) {
      matchedRules.push('R03');
      if (!minClass || minClass < 'C4') minClass = 'C4';
    }

    // R04/R05: Evidence critical
    if (scores.evidenceValue >= 5 && scores.traceabilityScore >= 5) {
      matchedRules.push('R04');
      matchedRules.push('R05');
      minClass = 'C5';
    }

    // R06: Calibration
    if (scores.evidenceValue >= 5 && scores.integrityScore >= 5) {
      matchedRules.push('R06');
      minClass = 'C5';
    }

    // R09: Security
    if (scores.securityScore >= 4) {
      matchedRules.push('R09');
      if (!minClass || minClass < 'C4') minClass = 'C4';
    }

    return { minClass, rules: matchedRules };
  };

  const calculateConfidence = (totalScore: number, matchedRules: string[]): number => {
    let confidence = 0.5;
    confidence += Math.min(matchedRules.length * 0.1, 0.3);
    if (totalScore >= 30) confidence += 0.15;
    return Math.min(confidence, 0.99);
  };

  const getProtectionActions = (classification: string): string[] => {
    const actions: Record<string, string[]> = {
      C1: ['Standard encryption at rest', 'TLS in transit', 'Checksum validation'],
      C2: ['Encryption at rest', 'TLS in transit', 'RBAC', 'Versioning'],
      C3: ['Strong encryption', 'Field encryption', 'Detailed access logging', 'Backup'],
      C4: ['Envelope encryption', 'Field-level encryption', 'MFA required', 'Export approval', 'DLP'],
      C5: ['Immutable vault storage', 'Digital signature', 'Dual control', 'WORM storage', 'Long retention (10+ years)'],
    };
    return actions[classification] || [];
  };

  const handleCalculate = async () => {
    setIsProcessing(true);
    
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 800));

    const totalScore = Object.values(riskScores).reduce((sum, score) => sum + score, 0);
    const baseClass = calculateClassification(totalScore);
    const overrides = applyOverrides(riskScores);
    
    // Determine final classification
    let finalClass = baseClass;
    if (overrides.minClass) {
      const classOrder = ['C1', 'C2', 'C3', 'C4', 'C5'];
      const baseIndex = classOrder.indexOf(baseClass);
      const overrideIndex = classOrder.indexOf(overrides.minClass);
      if (overrideIndex > baseIndex) {
        finalClass = overrides.minClass;
      }
    }

    const confidence = calculateConfidence(totalScore, overrides.rules);
    const protectionActions = getProtectionActions(finalClass);

    setResult({
      classification: finalClass,
      confidence,
      totalScore,
      matchedRules: overrides.rules,
      protectionActions,
    });

    // Save to database
    try {
      await fetch('/api/classify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: selectedData?.name || 'Manual Classification',
          sourceType: selectedData?.dataType || 'manual',
          riskScores,
          matchedRules: overrides.rules,
        }),
      });
    } catch (error) {
      console.error('Error saving classification:', error);
    }

    setIsProcessing(false);
  };

  const handleSelectSimulation = (item: SimulationItem) => {
    setSelectedData(item);
    try {
      const factors = JSON.parse(item.riskFactors);
      setRiskScores({
        piiScore: factors.piiScore || 0,
        geospatialScore: factors.geospatialScore || 0,
        carbonCriticality: factors.carbonCriticality || 0,
        evidenceValue: factors.evidenceValue || 0,
        legalScore: factors.legalScore || 0,
        businessScore: factors.businessScore || 0,
        integrityScore: factors.integrityScore || 0,
        availabilityScore: factors.availabilityScore || 0,
        traceabilityScore: factors.traceabilityScore || 0,
        securityScore: factors.securityScore || 0,
      });
    } catch {
      // Default scores if parsing fails
    }
    setResult(null);
  };

  const updateScore = (key: string, value: number) => {
    setRiskScores(prev => ({ ...prev, [key]: value }));
    setResult(null);
  };

  const totalScore = Object.values(riskScores).reduce((sum, score) => sum + score, 0);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 w-48 bg-muted rounded" />
            <div className="h-64 bg-muted rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Data Source Selector */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Simulation Data Source
          </CardTitle>
          <CardDescription>
            Select a sample data type or manually adjust risk scores
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Select onValueChange={(value) => {
            const item = simulationData.find(d => d.id === value);
            if (item) handleSelectSimulation(item);
          }}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select a data sample..." />
            </SelectTrigger>
            <SelectContent>
              {simulationData.map((item) => (
                <SelectItem key={item.id} value={item.id}>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{item.dataType}</Badge>
                    <span>{item.name}</span>
                    <Badge 
                      style={{ backgroundColor: classificationColors[item.expectedClass] }}
                      className="text-white ml-2"
                    >
                      {item.expectedClass}
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {selectedData && (
            <div className="mt-4 p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground">{selectedData.description}</p>
              <div className="mt-2 flex items-center gap-2">
                <span className="text-sm font-medium">Expected Classification:</span>
                <Badge 
                  style={{ backgroundColor: classificationColors[selectedData.expectedClass] }}
                  className="text-white"
                >
                  {selectedData.expectedClass} - {classificationLabels[selectedData.expectedClass]}
                </Badge>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Risk Score Sliders */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Risk Score Assessment
          </CardTitle>
          <CardDescription>
            Adjust each risk factor score from 0 (none) to 5 (critical)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {riskFactorsConfig.map((factor) => (
            <div key={factor.key} className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-medium">{factor.label}</span>
                  <p className="text-xs text-muted-foreground">{factor.description}</p>
                </div>
                <Badge 
                  variant="outline"
                  className={`
                    ${riskScores[factor.key as keyof RiskScore] === 0 ? 'bg-gray-100' : ''}
                    ${riskScores[factor.key as keyof RiskScore] >= 1 && riskScores[factor.key as keyof RiskScore] <= 2 ? 'bg-green-100 text-green-700' : ''}
                    ${riskScores[factor.key as keyof RiskScore] >= 3 && riskScores[factor.key as keyof RiskScore] <= 4 ? 'bg-yellow-100 text-yellow-700' : ''}
                    ${riskScores[factor.key as keyof RiskScore] === 5 ? 'bg-red-100 text-red-700' : ''}
                  `}
                >
                  {riskScores[factor.key as keyof RiskScore]}
                </Badge>
              </div>
              <Slider
                value={[riskScores[factor.key as keyof RiskScore]]}
                onValueChange={(value) => updateScore(factor.key, value[0])}
                max={5}
                step={1}
                className="w-full"
              />
            </div>
          ))}
          
          <Separator />
          
          {/* Total Score Display */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
            <div>
              <span className="font-semibold">Total Risk Score</span>
              <p className="text-xs text-muted-foreground">Sum of all risk factors</p>
            </div>
            <div className="text-right">
              <span className="text-3xl font-bold">{totalScore}</span>
              <span className="text-muted-foreground">/50</span>
            </div>
          </div>

          <Button 
            onClick={handleCalculate} 
            className="w-full"
            disabled={isProcessing}
          >
            {isProcessing ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <PlayCircle className="h-4 w-4 mr-2" />
                Run Classification
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Result */}
      {result && (
        <Card className="border-2" style={{ borderColor: classificationColors[result.classification] }}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Classification Result
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Main Result */}
            <div className="flex items-center justify-between p-6 rounded-lg bg-muted">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Classification</p>
                <div className="flex items-center gap-3">
                  <Badge 
                    style={{ backgroundColor: classificationColors[result.classification] }}
                    className="text-white text-xl py-2 px-4"
                  >
                    {result.classification}
                  </Badge>
                  <span className="text-2xl font-bold">
                    {classificationLabels[result.classification]}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground mb-1">Confidence</p>
                <span className="text-3xl font-bold">
                  {(result.confidence * 100).toFixed(1)}%
                </span>
                <Progress value={result.confidence * 100} className="mt-2 h-2 w-32" />
              </div>
            </div>

            {/* Matched Rules */}
            {result.matchedRules.length > 0 && (
              <div>
                <p className="font-semibold mb-2 flex items-center gap-2">
                  <Zap className="h-4 w-4 text-amber-500" />
                  Override Rules Applied
                </p>
                <div className="flex flex-wrap gap-2">
                  {result.matchedRules.map((rule) => (
                    <Badge key={rule} variant="secondary">
                      {rule}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Protection Actions */}
            <div>
              <p className="font-semibold mb-2 flex items-center gap-2">
                <Lock className="h-4 w-4" />
                Protection Actions
              </p>
              <div className="space-y-2">
                {result.protectionActions.map((action, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 rounded bg-muted/50">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">{action}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Comparison with Expected */}
            {selectedData && (
              <div className={`p-4 rounded-lg ${
                result.classification === selectedData.expectedClass 
                  ? 'bg-green-100 dark:bg-green-900/20' 
                  : 'bg-yellow-100 dark:bg-yellow-900/20'
              }`}>
                <div className="flex items-center gap-2">
                  {result.classification === selectedData.expectedClass ? (
                    <>
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <span className="font-medium text-green-700 dark:text-green-400">
                        Classification matches expected result
                      </span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="h-5 w-5 text-yellow-600" />
                      <span className="font-medium text-yellow-700 dark:text-yellow-400">
                        Classification differs from expected ({selectedData.expectedClass})
                      </span>
                    </>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
