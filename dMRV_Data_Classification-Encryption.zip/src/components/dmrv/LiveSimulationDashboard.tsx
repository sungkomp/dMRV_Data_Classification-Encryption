'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Database,
  Activity,
  Radio,
  Satellite,
  Plane,
  FileText,
  Server,
  Zap,
  PlayCircle,
  PauseCircle,
  RefreshCw,
  TrendingUp,
  Clock
} from 'lucide-react';

interface ClassificationEvent {
  id: string;
  assetId: string;
  assetName: string;
  sourceType: string;
  classification: string;
  classificationName: string;
  classificationColor: string;
  confidence: number;
  totalScore: number;
  riskScores: Record<string, number>;
  matchedRules: string[];
  timestamp: string;
}

interface SimulationStatus {
  running: boolean;
  count: number;
  message: string;
}

interface SimulationStats {
  total: number;
  c1: number;
  c2: number;
  c3: number;
  c4: number;
  c5: number;
}

const sourceTypeIcons: Record<string, React.ReactNode> = {
  sensor: <Radio className="h-4 w-4" />,
  iot: <Radio className="h-4 w-4" />,
  lidar: <Database className="h-4 w-4" />,
  satellite: <Satellite className="h-4 w-4" />,
  drone: <Plane className="h-4 w-4" />,
  evidence: <FileText className="h-4 w-4" />,
  document: <FileText className="h-4 w-4" />,
  database: <Server className="h-4 w-4" />,
};

export function LiveSimulationDashboard() {
  const [status, setStatus] = useState<SimulationStatus>({ running: false, count: 0, message: '' });
  const [events, setEvents] = useState<ClassificationEvent[]>([]);
  const [stats, setStats] = useState<SimulationStats>({ total: 0, c1: 0, c2: 0, c3: 0, c4: 0, c5: 0 });
  const [selectedEvent, setSelectedEvent] = useState<ClassificationEvent | null>(null);
  const [loading, setLoading] = useState(false);

  // Toggle simulation
  const toggleSimulation = useCallback(async () => {
    setLoading(true);
    try {
      if (status.running) {
        await fetch('/api/simulation/start', { method: 'DELETE' });
      } else {
        await fetch('/api/simulation/start', { method: 'POST' });
      }
      // Refetch status after toggle
      const res = await fetch('/api/simulation/start');
      setStatus(await res.json());
    } catch {
      console.error('Failed to toggle simulation');
    }
    setLoading(false);
  }, [status.running]);

  // Clear events
  const clearEvents = useCallback(() => {
    setEvents([]);
    setStats({ total: 0, c1: 0, c2: 0, c3: 0, c4: 0, c5: 0 });
  }, []);

  // Auto-refresh with proper cleanup
  useEffect(() => {
    let mounted = true;
    
    const fetchData = async () => {
      if (!mounted) return;
      
      try {
        const [statusRes, eventsRes] = await Promise.all([
          fetch('/api/simulation/start'),
          fetch('/api/simulation/events'),
        ]);
        
        if (!mounted) return;
        
        const statusData = await statusRes.json();
        const eventsData = await eventsRes.json();
        
        setStatus(statusData);
        setEvents(eventsData.events || []);
        setStats(eventsData.stats || { total: 0, c1: 0, c2: 0, c3: 0, c4: 0, c5: 0 });
      } catch {
        console.error('Failed to fetch data');
      }
    };
    
    // Initial fetch
    fetchData();
    
    // Set up polling interval
    const interval = setInterval(fetchData, 2000);
    
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="space-y-6">
      {/* Control Panel */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Live Classification Engine
              </CardTitle>
              <CardDescription>
                Real-time auto classification simulation
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={status.running ? 'default' : 'secondary'} className="flex items-center gap-1">
                {status.running ? (
                  <>
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    Running
                  </>
                ) : (
                  <>
                    <span className="w-2 h-2 rounded-full bg-gray-400" />
                    Stopped
                  </>
                )}
              </Badge>
              <Button 
                onClick={toggleSimulation}
                variant={status.running ? 'destructive' : 'default'}
                disabled={loading}
              >
                {status.running ? (
                  <>
                    <PauseCircle className="h-4 w-4 mr-2" />
                    Stop
                  </>
                ) : (
                  <>
                    <PlayCircle className="h-4 w-4 mr-2" />
                    Start
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={clearEvents}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Statistics */}
      <div className="grid gap-4 md:grid-cols-6">
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">C1 Public</p>
                <p className="text-2xl font-bold text-green-600">{stats.c1}</p>
              </div>
              <Badge className="bg-green-500 text-white">C1</Badge>
            </div>
            <Progress value={(stats.c1 / Math.max(stats.total, 1)) * 100} className="mt-2 h-1" />
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">C2 Internal</p>
                <p className="text-2xl font-bold text-blue-600">{stats.c2}</p>
              </div>
              <Badge className="bg-blue-500 text-white">C2</Badge>
            </div>
            <Progress value={(stats.c2 / Math.max(stats.total, 1)) * 100} className="mt-2 h-1" />
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-yellow-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">C3 Confidential</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.c3}</p>
              </div>
              <Badge className="bg-yellow-500 text-white">C3</Badge>
            </div>
            <Progress value={(stats.c3 / Math.max(stats.total, 1)) * 100} className="mt-2 h-1" />
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">C4 Restricted</p>
                <p className="text-2xl font-bold text-orange-600">{stats.c4}</p>
              </div>
              <Badge className="bg-orange-500 text-white">C4</Badge>
            </div>
            <Progress value={(stats.c4 / Math.max(stats.total, 1)) * 100} className="mt-2 h-1" />
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">C5 Evidence-Critical</p>
                <p className="text-2xl font-bold text-purple-600">{stats.c5}</p>
              </div>
              <Badge className="bg-purple-500 text-white">C5</Badge>
            </div>
            <Progress value={(stats.c5 / Math.max(stats.total, 1)) * 100} className="mt-2 h-1" />
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total Processed</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Live Feed */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            Live Classification Feed
          </CardTitle>
          <CardDescription>
            Real-time stream of classified data assets ({events.length} events)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            {events.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
                <Activity className="h-12 w-12 mb-4 opacity-50" />
                <p>No classification events yet</p>
                <p className="text-sm">Click Start to begin simulation</p>
              </div>
            ) : (
              <div className="space-y-2">
                {events.map((event) => (
                  <Card 
                    key={event.id} 
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => setSelectedEvent(event)}
                  >
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-muted">
                            {sourceTypeIcons[event.sourceType] || <Database className="h-4 w-4" />}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{event.assetName}</span>
                              {event.matchedRules && event.matchedRules.length > 0 && (
                                <Badge variant="outline" className="text-xs">
                                  <Zap className="h-3 w-3 mr-1 text-yellow-500" />
                                  {event.matchedRules.length} rules
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <span className="capitalize">{event.sourceType}</span>
                              <span>•</span>
                              <Clock className="h-3 w-3" />
                              <span>{new Date(event.timestamp).toLocaleTimeString()}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <Badge 
                              style={{ backgroundColor: event.classificationColor }}
                              className="text-white"
                            >
                              {event.classification}
                            </Badge>
                            <p className="text-xs text-muted-foreground mt-1">
                              {(event.confidence * 100).toFixed(0)}% confidence
                            </p>
                          </div>
                          <div className="w-24">
                            <p className="text-xs text-muted-foreground mb-1">Risk Score</p>
                            <Progress value={event.totalScore} max={50} className="h-2" />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Event Detail Dialog */}
      <Dialog open={!!selectedEvent} onOpenChange={() => setSelectedEvent(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedEvent && sourceTypeIcons[selectedEvent.sourceType]}
              {selectedEvent?.assetName}
            </DialogTitle>
            <DialogDescription>
              Classification details
            </DialogDescription>
          </DialogHeader>
          
          {selectedEvent && (
            <ScrollArea className="max-h-[60vh]">
              <div className="space-y-4">
                {/* Classification Result */}
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
                  <div>
                    <p className="text-sm text-muted-foreground">Classification</p>
                    <Badge 
                      style={{ backgroundColor: selectedEvent.classificationColor }}
                      className="text-white text-lg py-1 px-3"
                    >
                      {selectedEvent.classification}
                    </Badge>
                    <p className="text-sm mt-1">{selectedEvent.classificationName}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Confidence</p>
                    <p className="text-2xl font-bold">{(selectedEvent.confidence * 100).toFixed(1)}%</p>
                  </div>
                </div>

                {/* Risk Scores */}
                <div>
                  <h4 className="font-semibold mb-2">Risk Scores</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {Object.entries(selectedEvent.riskScores).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between p-2 rounded bg-muted/50">
                        <span className="text-sm capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                        <Badge variant="outline">{value}</Badge>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between mt-2 p-2 rounded bg-muted">
                    <span className="font-medium">Total Score</span>
                    <span className="text-xl font-bold">{selectedEvent.totalScore}</span>
                  </div>
                </div>

                {/* Matched Rules */}
                {selectedEvent.matchedRules && selectedEvent.matchedRules.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Matched Rules</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedEvent.matchedRules.map((rule) => (
                        <Badge key={rule} variant="secondary">
                          <Zap className="h-3 w-3 mr-1 text-yellow-500" />
                          {rule}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Timestamp */}
                <div className="text-sm text-muted-foreground">
                  <Clock className="h-4 w-4 inline mr-1" />
                  {new Date(selectedEvent.timestamp).toLocaleString()}
                </div>
              </div>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
