'use client';

import { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Shield,
  Lock,
  Key,
  Eye,
  Database,
  Clock,
  HardDrive,
  FileCheck,
  AlertTriangle,
  CheckCircle,
  XCircle
} from 'lucide-react';

interface ProtectionPolicy {
  id: string;
  name: string;
  classification: {
    id: string;
    code: string;
    name: string;
    color: string;
  };
  encryptionAtRest: string | null;
  encryptionInTransit: string | null;
  fieldEncryption: boolean;
  tokenization: boolean;
  accessControl: string | null;
  mfaRequired: boolean;
  immutableStorage: boolean;
  wormStorage: boolean;
  evidenceVault: boolean;
  auditLogging: boolean;
  detailedLogging: boolean;
  retentionYears: number | null;
  backupFrequency: string | null;
  backupType: string | null;
  exportApproval: boolean;
  externalSharing: boolean;
}

const classificationColors: Record<string, string> = {
  C1: '#22C55E',
  C2: '#3B82F6',
  C3: '#F59E0B',
  C4: '#EF4444',
  C5: '#7C3AED',
};

export function ProtectionPolicies() {
  const [policies, setPolicies] = useState<ProtectionPolicy[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const res = await fetch('/api/policies');
        const data = await res.json();
        setPolicies(data);
      } catch (error) {
        console.error('Error fetching policies:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const getBooleanIcon = (value: boolean) => 
    value ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-gray-300" />;

  if (loading) {
    return (
      <Card>
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 w-48 bg-muted rounded" />
            <div className="h-64 bg-muted rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Policy Cards by Classification */}
      <div className="grid gap-4 md:grid-cols-5">
        {policies.map((policy) => (
          <Card 
            key={policy.id}
            className="overflow-hidden"
            style={{ borderTopColor: classificationColors[policy.classification.code], borderTopWidth: 4 }}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Badge 
                  style={{ backgroundColor: classificationColors[policy.classification.code] }}
                  className="text-white font-bold"
                >
                  {policy.classification.code}
                </Badge>
                <span className="text-sm font-medium">{policy.classification.name}</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Encryption</span>
                  {policy.encryptionAtRest ? (
                    <Badge variant="outline" className="text-xs">{policy.encryptionAtRest}</Badge>
                  ) : (
                    <span className="text-xs text-muted-foreground">None</span>
                  )}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Access</span>
                  <Badge variant="outline" className="text-xs">{policy.accessControl || 'Open'}</Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">MFA</span>
                  {getBooleanIcon(policy.mfaRequired)}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Immutable</span>
                  {getBooleanIcon(policy.immutableStorage)}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Retention</span>
                  <span className="text-xs font-medium">{policy.retentionYears || 0} years</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Detailed Policy Matrix */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Protection Policy Matrix
          </CardTitle>
          <CardDescription>
            Complete mapping of classification levels to protection controls
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Control</TableHead>
                {policies.map((p) => (
                  <TableHead key={p.id} className="text-center">
                    <Badge 
                      style={{ backgroundColor: classificationColors[p.classification.code] }}
                      className="text-white"
                    >
                      {p.classification.code}
                    </Badge>
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Encryption at Rest</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    <Badge variant="outline" className="capitalize">
                      {p.encryptionAtRest || 'None'}
                    </Badge>
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Encryption in Transit</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    <Badge variant="outline" className="uppercase">
                      {p.encryptionInTransit || 'None'}
                    </Badge>
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Field-level Encryption</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.fieldEncryption)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Tokenization</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.tokenization)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Access Control</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    <span className="text-sm capitalize">{p.accessControl?.replace('-', ' ') || 'Open'}</span>
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">MFA Required</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.mfaRequired)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Immutable Storage</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.immutableStorage)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">WORM Storage</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.wormStorage)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Evidence Vault</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.evidenceVault)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Audit Logging</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.auditLogging)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Detailed Logging</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.detailedLogging)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Retention (Years)</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center font-bold">
                    {p.retentionYears || 0}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Export Approval</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.exportApproval)}
                  </TableCell>
                ))}
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">External Sharing</TableCell>
                {policies.map((p) => (
                  <TableCell key={p.id} className="text-center">
                    {getBooleanIcon(p.externalSharing)}
                  </TableCell>
                ))}
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Control Objectives */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Lock className="h-4 w-4" />
              Control Objectives by Classification
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {[
              { class: 'C1', color: '#22C55E', objective: 'Protect against accidental modification and maintain public data integrity' },
              { class: 'C2', color: '#3B82F6', objective: 'Restrict access to internal users, reduce operational risk' },
              { class: 'C3', color: '#F59E0B', objective: 'Reduce business and operational privacy risk, maintain access evidence' },
              { class: 'C4', color: '#EF4444', objective: 'Prevent leaks, unauthorized access, and tampering of sensitive data' },
              { class: 'C5', color: '#7C3AED', objective: 'Protect evidentiary value, accuracy, continuity, and auditability' },
            ].map((item) => (
              <div key={item.class} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                <Badge style={{ backgroundColor: item.color }} className="text-white shrink-0">
                  {item.class}
                </Badge>
                <p className="text-sm">{item.objective}</p>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="h-4 w-4" />
              Protection Action Types
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { action: 'Encrypt File', desc: 'Apply encryption to entire file object', icon: Lock },
              { action: 'Encrypt Fields', desc: 'Encrypt specific sensitive fields in database', icon: Key },
              { action: 'Tokenize PII', desc: 'Replace PII with non-reversible tokens', icon: Eye },
              { action: 'Move to Vault', desc: 'Transfer to immutable evidence vault', icon: Database },
              { action: 'Apply Signature', desc: 'Attach cryptographic signature/hash', icon: FileCheck },
              { action: 'Enforce Retention', desc: 'Apply retention policy and backup schedule', icon: Clock },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                <div className="p-2 rounded-lg bg-primary/10">
                  <item.icon className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-sm">{item.action}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
