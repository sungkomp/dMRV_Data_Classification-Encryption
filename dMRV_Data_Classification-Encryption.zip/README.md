# dMRV Auto Data Classification & Encryption System

<div align="center">

![Next.js](https://img.shields.io/badge/Next.js-16-black?style=flat-square&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-38B2AC?style=flat-square&logo=tailwind-css)
![Prisma](https://img.shields.io/badge/Prisma-6-2D3748?style=flat-square&logo=prisma)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)

**ระบบจัดชั้นข้อมูลและเข้ารหัสอัตโนมัติสำหรับ dMRV**  
Auto Data Classification & Encryption Engine for Digital Measurement, Reporting and Verification

[Live Demo](#demo) • [Features](#features) • [Architecture](#architecture) • [Installation](#installation)

</div>

---

## 📋 Overview

ระบบนี้ออกแบบมาสำหรับจัดการข้อมูลในระบบ dMRV (Digital Measurement, Reporting and Verification) โดยมีความสามารถหลัก:

- **🔐 จัดชั้นข้อมูลอัตโนมัติ (Auto Classification)** - จำแนกระดับความลับของข้อมูลเป็น 5 ระดับ (C1-C5)
- **🛡️ บังคับใช้การเข้ารหัส (Encryption Enforcement)** - เลือกมาตรการป้องกันตามระดับข้อมูล
- **📊 ประเมินความเสี่ยง (Risk Assessment)** - คำนวณคะแนนความเสี่ยงจากหลายปัจจัย
- **🔍 ตรวจสอบย้อนหลัง (Audit Trail)** - บันทึกการตัดสินใจและการกระทำทั้งหมด

## 🎯 Features

### 1. Data Classification System
จัดชั้นข้อมูลเป็น 5 ระดับ:

| Level | Name | Description |
|-------|------|-------------|
| **C1** | Public | ข้อมูลเปิดเผยได้ |
| **C2** | Internal | ใช้ภายในองค์กร |
| **C3** | Confidential | ข้อมูลสำคัญของโครงการ |
| **C4** | Restricted | ข้อมูลอ่อนไหวสูง |
| **C5** | Evidence-Critical | หลักฐานสำคัญในการ verification |

### 2. Risk Scoring Engine
ประเมินความเสี่ยงจาก 10 ปัจจัย:
- PII / Personal Linkage
- Geospatial Sensitivity
- Carbon Criticality
- Evidence Value
- Legal / Contractual
- Business Sensitivity
- Integrity Impact
- Availability Impact
- Traceability
- Security Exploitability

### 3. Auto Classification Engine
ระบบตัดสินใจแบบ Hybrid:
- ✅ Rule-based Engine (กฎที่กำหนด)
- ✅ ML/NLP Classifier (การเรียนรู้)
- ✅ Risk Scoring Engine (คะแนนความเสี่ยง)
- ✅ Policy Override Manager (แทนที่ตามนโยบาย)

### 4. Protection Policies
มาตรการป้องกันตามระดับข้อมูล:
- 🔒 Encryption at Rest / in Transit
- 🔑 Field-level Encryption
- 🎫 Tokenization
- 📁 Immutable Storage (WORM)
- 🏛️ Evidence Vault
- 📝 Audit Logging
- ⏱️ Retention Policy

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    Data Ingress & Event Trigger                  │
│   (Sensor, IoT, LiDAR, Satellite, Drone, Documents, APIs)      │
└─────────────────────────────┬───────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Data Discovery & Extraction                    │
│   (Metadata, Content, OCR/NLP, Geospatial, Context)             │
└─────────────────────────────┬───────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Core Decision Engine                        │
│   (Rule Engine, ML/NLP, Risk Scoring, Decision Aggregator)      │
└─────────────────────────────┬───────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Policy Orchestration                          │
│   (Policy Mapper, Encryption Orchestrator, Key Management)      │
└─────────────────────────────┬───────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                 Trust, Audit & Evidence Layer                    │
│   (Classification Registry, Evidence Integrity, Audit Log)      │
└─────────────────────────────┬───────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│               Human Review & Governance Layer                    │
│   (Review Workbench, Exception Management, Policy Console)      │
└─────────────────────────────────────────────────────────────────┘
```

## 🗃️ Data Sources Supported

| Type | Examples | Classification |
|------|----------|---------------|
| **Sensor/IoT** | Methane flux, Soil moisture, Temperature | C2-C4 |
| **LiDAR** | Forest biomass, Canopy height | C5 |
| **Satellite** | Sentinel, Landsat imagery | C2-C3 |
| **Drone** | Orthomosaic, Field imagery | C3-C4 |
| **Evidence** | Verification reports, Calibration certs | C5 |
| **Database** | Parcel registry, Owner data | C4 |

## 🚀 Installation

### Prerequisites
- Node.js 18+
- Bun or npm
- SQLite

### Setup

```bash
# Clone the repository
git clone https://github.com/your-username/dmrv-classification-system.git
cd dmrv-classification-system

# Install dependencies
bun install

# Setup database
bun run db:push

# Seed initial data
bun run prisma/seed.ts

# Start development server
bun run dev
```

### Environment Variables

Create `.env` file:
```env
DATABASE_URL="file:./db/custom.db"
```

## 📱 Screenshots

### Dashboard
![Dashboard](./docs/screenshots/dashboard.png)

### Classification Matrix
![Classification](./docs/screenshots/classification.png)

### Risk Calculator
![Calculator](./docs/screenshots/calculator.png)

### Architecture View
![Architecture](./docs/screenshots/architecture.png)

## 🔧 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/classification/levels` | GET | Get all classification levels |
| `/api/classification/rules` | GET | Get all classification rules |
| `/api/assets` | GET | List all classified assets |
| `/api/simulation` | GET | Get simulation data samples |
| `/api/risk-reasons` | GET | Get risk reason codes |
| `/api/policies` | GET | Get protection policies |
| `/api/classify` | POST | Classify new data |

### Example: Classify Data

```bash
curl -X POST http://localhost:3000/api/classify \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Methane Sensor Data",
    "sourceType": "sensor",
    "riskScores": {
      "piiScore": 0,
      "geospatialScore": 2,
      "carbonCriticality": 5,
      "evidenceValue": 4,
      "legalScore": 2,
      "businessScore": 3,
      "integrityScore": 5,
      "availabilityScore": 4,
      "traceabilityScore": 5,
      "securityScore": 2
    },
    "matchedRules": ["R03"]
  }'
```

## 📚 Standards Compliance

- ✅ ISO/IEC 27001:2022
- ✅ NIST Cybersecurity Framework 2.0
- ✅ Data Classification Best Practices

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📞 Contact

For questions or support, please open an issue on GitHub.

---

<div align="center">
  <p>Built with ❤️ for Carbon Credit Verification</p>
</div>
